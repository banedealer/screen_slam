//
//  HelpScreen.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/16/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import "HelpScreen.h"

@interface HelpScreen ()

@end

@implementation HelpScreen
@synthesize appDelegate;
@synthesize helpScroll;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [helpScroll flashScrollIndicators];
    [helpScroll setScrollEnabled:YES];
    [helpScroll setContentSize:CGSizeMake(260, 640+88)];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)closeHelpScreen:(id)sender {
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
@end
