//
//  MediaSelection.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface MediaSelection : UIViewController <UIGestureRecognizerDelegate>{
    AppDelegate *appDelegate;
}

@property (nonatomic, retain) AppDelegate *appDelegate;
@property (strong, nonatomic) IBOutlet UIScrollView *genreScroll;

@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *genreLoader;

@property (strong, nonatomic) IBOutlet UIButton *bPromo;
@property (strong, nonatomic) IBOutlet UIButton *g0;
@property (strong, nonatomic) IBOutlet UIButton *g1;
@property (strong, nonatomic) IBOutlet UIButton *g2;
@property (strong, nonatomic) IBOutlet UIButton *g3;

- (IBAction)generatePromoMedia:(id)sender;
- (IBAction)generateDramaMedia:(id)sender;
- (IBAction)generateComedyMedia:(id)sender;
- (IBAction)generateScifiMedia:(id)sender;
- (IBAction)generateActionMedia:(id)sender;
- (IBAction)generateHorrorMedia:(id)sender;
- (IBAction)generateFamilyMedia:(id)sender;
- (IBAction)generateAllMedia:(id)sender;

- (void) generateMedia:(NSString *)type;

@end
