//
//  User.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/3/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import "User.h"

@implementation User
@synthesize id,fid,fname,lname,thumbnail,score,won,opponent_won,timeSpends, game_score;

@end
