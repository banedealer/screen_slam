//
//  PrivacyScreen.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/16/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import "PrivacyScreen.h"

@interface PrivacyScreen ()

@end

@implementation PrivacyScreen
@synthesize privacyScroll;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [privacyScroll flashScrollIndicators];
    [privacyScroll setScrollEnabled:YES];
    [privacyScroll setContentSize:CGSizeMake(260, 6096+88)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)closePrivacyScreen:(id)sender {
    NSLog(@"aaaa");
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
@end
