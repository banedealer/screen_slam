//
//  ViewController.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "ViewController.h"
#import "ChoosePlayerType.h"
#import "GenreStarter.h"
#import "MediaSelection.h"
#import "GameplayResult.h"
#import "TBXML+HTTP.h"
#import "AppDelegate.h"
#import "FacebookLogin.h"
#import "RoundDetailResult.h"
#import "HelpScreen.h"
#import "TermsScreen.h"
#import "PrivacyScreen.h"
//#import <FacebookSDK/FacebookSDK.h>
#import "Facebook.h"
#import "User.h"
#import <sys/utsname.h>
#import "Reachability.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize appDelegate;
@synthesize bTerms, bPrivacy;
@synthesize pChallenges;
@synthesize imgInstruction;
@synthesize imgPromo, preloaderPanel;
@synthesize connect,request,tempData;
@synthesize imgProfile, txtScore, bStart, txtFName,txtUID,bFBConnet;
@synthesize challengeScroll;
@synthesize navController;


-(void)connectionErrorAlert:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(connectionErrorAlertInMain) withObject:nil waitUntilDone:YES];
}
-(void)connectionErrorAlertInMain {
    self.view.userInteractionEnabled = YES;
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Error"
                              message:@"Sorry! The connection to the server was lost."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
    [alertView show];
    
    
    [UIView beginAnimations:@"LeftFlip" context:nil];
    [UIView setAnimationDuration:0.8];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:navController.view.superview cache:YES];
    [UIView commitAnimations];
    [navController dismissViewControllerAnimated:NO completion:nil];
}

-(void)mainConnectionErrorAlert:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(mainConnectionErrorAlertInMain) withObject:nil waitUntilDone:YES];
}
-(void)mainConnectionErrorAlertInMain {
    
    self.view.userInteractionEnabled = YES;
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Error"
                              message:@"Sorry! The connection to the server was lost."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
    [alertView show];
    
}

// static function that handle xml parsing
TBXMLFailureBlock loadGameInfoFailure = ^(TBXML *tbxmlDocument, NSError * error) {
    NSLog(@"Error! %@ %@", [error localizedDescription], [error userInfo]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"mainConnectionError" object:nil];
};

TBXMLSuccessBlock loadGameInfoSuccess = ^(TBXML *tbxmlDocument) {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    
    TBXMLElement *rootElement = tbxmlDocument.rootXMLElement;
    
    // parse promo data
    TBXMLElement *promo = [TBXML childElementNamed:@"promo" parentElement:rootElement];
    TBXMLElement *promo_display = [TBXML childElementNamed:@"display" parentElement:promo];
    if ([[TBXML textForElement:promo_display] isEqualToString:@"1"]){
        TBXMLElement *promo_name = [TBXML childElementNamed:@"name" parentElement:promo];
        appDelegate.promo_name = [TBXML textForElement:promo_name];
    }else{
        appDelegate.promo_name = @"";
    }
    
    // parse user data
    appDelegate.user = [[User alloc] init];
    TBXMLElement *user = [TBXML childElementNamed:@"user" parentElement:rootElement];    
    TBXMLElement *user_id = [TBXML childElementNamed:@"user_id" parentElement:user];
    appDelegate.user.id = [TBXML textForElement:user_id];
    TBXMLElement *user_fid = [TBXML childElementNamed:@"user_fid" parentElement:user];
    appDelegate.user.fid = [TBXML textForElement:user_fid];
    // store the user id to the device if it is a non-fb user
    if ([appDelegate.user.fid isEqualToString:@"0"]){
        NSLog(@"storing user id to the device");
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:[TBXML textForElement:user_id] forKey:@"uid"];
    }
    // if the device token is set
    if (appDelegate.deviceToken != nil){        
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/registerDeviceToken.php?user_id=%d&deviceToken=%@", appDelegate.BASE_URL, [appDelegate.user.id integerValue], appDelegate.deviceToken]]];
        
        data = nil;
    }
    // save the device type for analytics
    struct utsname u;
    uname(&u);
    NSString *machine = [[NSString stringWithFormat:@"%s", u.machine] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/registerDeviceType.php?user_id=%d&deviceType=%@", appDelegate.BASE_URL, [appDelegate.user.id integerValue], machine]]];
    data = nil;
    
    TBXMLElement *user_fname = [TBXML childElementNamed:@"user_fname" parentElement:user];
    appDelegate.user.fname = [TBXML textForElement:user_fname];
    TBXMLElement *user_lname = [TBXML childElementNamed:@"user_lname" parentElement:user];
    appDelegate.user.lname = [TBXML textForElement:user_lname];
    TBXMLElement *user_thumbnail = [TBXML childElementNamed:@"user_thumbnail" parentElement:user];
    appDelegate.user.thumbnail = [TBXML textForElement:user_thumbnail];
    TBXMLElement *user_score = [TBXML childElementNamed:@"user_score" parentElement:user];
    appDelegate.user.score = [[TBXML textForElement:user_score] integerValue];
    // parser challenge data
    
    
    TBXMLElement *gameplays = [TBXML childElementNamed:@"gameplays" parentElement:rootElement];
    TBXMLElement *gameplay = [TBXML childElementNamed:@"gameplay" parentElement:gameplays];
    
    appDelegate.challenge_id_array = [[NSMutableArray alloc] init];
    appDelegate.challenge_genre_type_array = [[NSMutableArray alloc] init];
    appDelegate.gameplay_status = [[NSMutableArray alloc] init];
    appDelegate.gameplay_round_array = [[NSMutableArray alloc] init];
    appDelegate.challenge_game_id_array = [[NSMutableArray alloc] init];
    appDelegate.challenge_player = [[NSMutableArray alloc] init];
    
    
    while (gameplay != nil){
        
        TBXMLElement *challenge_id_array = [TBXML childElementNamed:@"challenge_id" parentElement:gameplay];
        [appDelegate.challenge_id_array addObject:[TBXML textForElement:challenge_id_array]];
        
        TBXMLElement *challenge_genre_type_array = [TBXML childElementNamed:@"challenge_genre_type" parentElement:gameplay];
        [appDelegate.challenge_genre_type_array addObject:[TBXML textForElement:challenge_genre_type_array]];
        
        TBXMLElement *challenge_game_id_array = [TBXML childElementNamed:@"gameplay_game_id" parentElement:gameplay];
        [appDelegate.challenge_game_id_array addObject:[TBXML textForElement:challenge_game_id_array]];
        
        TBXMLElement *gameplay_status = [TBXML childElementNamed:@"gameplay_status" parentElement:gameplay];
        [appDelegate.gameplay_status addObject:[TBXML textForElement:gameplay_status]];
        
        TBXMLElement *gameplay_round_array = [TBXML childElementNamed:@"gameplay_round" parentElement:gameplay];
        [appDelegate.gameplay_round_array addObject:[TBXML textForElement:gameplay_round_array]];
        
        User *player = [[User alloc] init];
        
        TBXMLElement *challenge_player_user_id_array = [TBXML childElementNamed:@"player_user_id" parentElement:gameplay];
        //[appDelegate.challenge_player_user_id_array addObject:[TBXML textForElement:challenge_player_user_id_array]];
        player.id = [TBXML textForElement:challenge_player_user_id_array];
        
        TBXMLElement *challenge_player_user_fid_array = [TBXML childElementNamed:@"player_user_fid" parentElement:gameplay];
        //[appDelegate.challenge_player_user_fid_array addObject:[TBXML textForElement:challenge_player_user_fid_array]];
        player.fid = [TBXML textForElement:challenge_player_user_fid_array];
        
        TBXMLElement *challenge_player_user_fname_array = [TBXML childElementNamed:@"player_user_fname" parentElement:gameplay];
        //[appDelegate.challenge_player_user_fname_array addObject:[TBXML textForElement:challenge_player_user_fname_array]];
        player.fname = [TBXML textForElement:challenge_player_user_fname_array];
        
        TBXMLElement *challenge_player_user_lname_array = [TBXML childElementNamed:@"player_user_lname" parentElement:gameplay];
        //[appDelegate.challenge_player_user_lname_array addObject:[TBXML textForElement:challenge_player_user_lname_array]];
        player.lname = [TBXML textForElement:challenge_player_user_lname_array];
        
        TBXMLElement *challenge_player_user_thumbnail_array = [TBXML childElementNamed:@"player_user_thumbnail" parentElement:gameplay];
        //[appDelegate.challenge_player_user_thumbnail_array addObject:[TBXML textForElement:challenge_player_user_thumbnail_array]];
        player.thumbnail = [TBXML textForElement:challenge_player_user_thumbnail_array];
        
        TBXMLElement *challenge_player_user_score_array = [TBXML childElementNamed:@"player_user_score" parentElement:gameplay];
        //[appDelegate.challenge_player_user_score_array addObject:[TBXML textForElement:challenge_player_user_score_array]];
        player.score = [[TBXML textForElement:challenge_player_user_score_array] integerValue];
        
        TBXMLElement *gameplay_player_won = [TBXML childElementNamed:@"gameplay_player_won" parentElement:gameplay];
        player.won = [[TBXML textForElement:gameplay_player_won] integerValue];
        
        TBXMLElement *gameplay_user_won = [TBXML childElementNamed:@"gameplay_user_won" parentElement:gameplay];
        player.opponent_won = [[TBXML textForElement:gameplay_user_won] integerValue];
        
        [appDelegate.challenge_player addObject:player];
        
        gameplay = [TBXML nextSiblingNamed:@"gameplay" searchFromElement:gameplay];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"gameInfoLoaded" object:nil];
};


- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
    NSLog(@"connection error");
}

- (void)connection: (NSURLConnection *)connection didReceiveResponse:
(NSURLResponse *)aResponse
{
    NSLog(@"connection establish");
}

-(void) connection:(NSURLConnection *)connection didReceiveData:
(NSData *) incomingData
{
    [tempData appendData:incomingData];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSArray *pathList = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [pathList objectAtIndex:0];
        
    path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"profileIMG"]];
    NSLog(@"path：%@", path);
    
    [tempData writeToFile:path atomically:NO];    
    tempData = nil;
    
    appDelegate.imgUserData = [UIImage imageWithContentsOfFile:path];
    [imgProfile setImage:appDelegate.imgUserData];
    
    //self.view.userInteractionEnabled = YES;
    //pChallenges.hidden = YES;
}

-(void)displayFBScreen:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(showFBConnectScreen) withObject:nil waitUntilDone:YES];
}

-(void)initGame:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(initGameContent) withObject:nil waitUntilDone:YES];
}

-(void)reloadGameInfo:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(loadGameInfo) withObject:nil waitUntilDone:YES];
}

-(void)launchUserTypeSelection:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(startUserTypeSelection) withObject:nil waitUntilDone:YES];
}

-(void)launchMediaSelection:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(startMediaSelection) withObject:nil waitUntilDone:YES];
}

-(void)freeChallengeScroll {
    // free challenger panel from previous call
    for (UIView *subview in challengeScroll.subviews){
        if (subview.tag != -1){
            [subview removeFromSuperview];
        }
    }
}

-(void)initGameContent {
    
    self.view.userInteractionEnabled = YES;
    pChallenges.hidden = YES;
    
    // display login/logout button
    if (appDelegate.FBConnected){
        [bFBConnet setTitle:@"LOGOUT" forState:UIControlStateNormal];
    }else{
        [bFBConnet setTitle:@"LOGIN" forState:UIControlStateNormal];
    }
    
    // display title
    [txtUID setText:[NSString stringWithFormat:@"%010d", [appDelegate.user.id integerValue]]];
    [txtFName setText:[NSString stringWithFormat:@"%@ %@", appDelegate.user.fname, appDelegate.user.lname]];
    if ([appDelegate.user.fid isEqualToString:@"0"]){
        [txtFName setText:[NSString stringWithFormat:@"%@", appDelegate.user.fname]];
    }
    [txtScore setText:[NSString stringWithFormat:@"%d", appDelegate.user.score]];
    
    // request remote profile img
    request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:appDelegate.user.thumbnail]];
    
    [request setHTTPMethod:@"GET"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"Mobile Safari 1.1.3 (iPhone; U; CPU like Mac OS X; en)" forHTTPHeaderField:@"User-Agent"];
    tempData = [NSMutableData alloc];
    connect = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    
    //[self freeChallengeScroll];
    
    
    // displayer challengers
    double height = 90+7;
    [challengeScroll flashScrollIndicators];
    [challengeScroll setScrollEnabled:YES];
    [challengeScroll setContentSize:CGSizeMake(260, 10+[appDelegate.challenge_id_array count]*height+88)];
    int i = 0;
    if ([appDelegate.challenge_id_array count] > 0){
        imgInstruction.hidden = YES;
    }else{
        imgInstruction.hidden = NO;
    }
    while (i < [appDelegate.challenge_id_array count]) {
        // get user info
        User *player = appDelegate.challenge_player[i];        
        
        // image panel
        UIImageView *imgPanel;
        if ([appDelegate.gameplay_status[i] isEqualToString:@"wait"] || [appDelegate.gameplay_status[i] isEqualToString:@"end"]){
            imgPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"panel_challengeboard_yellow_lighter.png"]];
        }else{
            imgPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"panel_challengeboard_yellow.png"]];
        }        
        imgPanel.frame = CGRectMake(8, 10+i*height, 266, 90);
        [challengeScroll addSubview:imgPanel];
        
        // player image panel
        NSData *playerPanelData = [NSData dataWithContentsOfURL:[NSURL URLWithString:player.thumbnail]];
        //NSData *playerPanelData = [NSData dataWithContentsOfURL:[NSURL URLWithString:appDelegate.challenge_player_user_thumbnail_array[i]]];
        UIImageView *playerPanel = [[UIImageView alloc] initWithImage:[UIImage imageWithData:playerPanelData]];
        playerPanel.contentMode = UIViewContentModeScaleAspectFill;
        playerPanel.clipsToBounds = YES;
        playerPanel.frame = CGRectMake(8+23, 10+i*height+7, 40, 40);
        [challengeScroll addSubview:playerPanel];
        
        
        // accept button
        UIButton *m = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        m.tag = i;
        [m setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateNormal];
        [m setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateDisabled];
        [m setBackgroundImage:[UIImage imageNamed:@"button_small_f1.png"] forState:UIControlStateNormal];
        [m setBackgroundImage:[UIImage imageNamed:@"button_small_f1.png"] forState:UIControlStateDisabled];
        [m addTarget:self action:@selector(gotoChallenge:) forControlEvents:UIControlEventTouchUpInside];
        m.frame = CGRectMake(145, 10+i*height+52, 106, 30);
        [m setTitle:@"CONTINUE" forState:UIControlStateNormal];
        [challengeScroll addSubview:m];
        if ([appDelegate.gameplay_status[i] isEqualToString:@"wait"]){
            // disable continue button
            m.enabled = NO;
            m.alpha = 0.6;
            
            // display waiting for opponent text
            UILabel *lbWait = [[UILabel alloc] initWithFrame:CGRectMake(147, 10+i*height+30, 180, 30)];
            lbWait.textColor = [UIColor colorWithRed:204/255.f green:102/255.f blue:51/255.f alpha:255/255.f];
            lbWait.backgroundColor = [UIColor clearColor];
            lbWait.text = @"WAITING FOR OPPONENT";            
            [lbWait setFont:[UIFont boldSystemFontOfSize:8]];
            [challengeScroll addSubview:lbWait];            
        }else if ([appDelegate.gameplay_status[i] isEqualToString:@"end"]){
            // disable continue button
            m.hidden = YES;
        }
        
        // display invisble history button
        UIButton *bHistory = [UIButton buttonWithType:UIButtonTypeCustom];
        bHistory.backgroundColor = [UIColor clearColor];
        bHistory.tag = i;
        [bHistory addTarget:self action:@selector(removeChallenge:) forControlEvents:UIControlEventTouchUpInside];
        bHistory.frame = CGRectMake(10, 10+i*height+0, 265, 50);        
        [challengeScroll addSubview:bHistory];
        
        // score of two player
        UILabel *lbWon = [[UILabel alloc] initWithFrame:CGRectMake(245, 10+i*height, 70, 30)];
        lbWon.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        lbWon.backgroundColor = [UIColor clearColor];
        [lbWon setText:[NSString stringWithFormat:@"%d:%d",player.opponent_won, player.won]];
        //[lbName setText:[NSString stringWithFormat:@"%@",appDelegate.challenge_player_user_fname_array[i]]];
        [lbWon setFont:[UIFont boldSystemFontOfSize:16]];
        [challengeScroll addSubview:lbWon];
        
        // result button
        UIButton *bDecline = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        bDecline.tag = i;
        [bDecline setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateNormal];
        [bDecline setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateDisabled];
        [bDecline setBackgroundImage:[UIImage imageNamed:@"button_small_f1.png"] forState:UIControlStateNormal];
        [bDecline setBackgroundImage:[UIImage imageNamed:@"button_small_f1.png"] forState:UIControlStateDisabled];
        
        bDecline.frame = CGRectMake(30, 10+i*height+52, 106, 30);
        if (player.opponent_won == 0 && player.won == 0){
            if ([appDelegate.gameplay_status[i] isEqualToString:@"accept"]){
                [bDecline addTarget:self action:@selector(declineGameplay:) forControlEvents:UIControlEventTouchUpInside];
                [m setTitle:@"ACCEPT" forState:UIControlStateNormal];
                [bDecline setTitle:@"DECLINE" forState:UIControlStateNormal];
            }else if ([appDelegate.gameplay_status[i] isEqualToString:@"end"]){
                [lbWon setText:[NSString stringWithFormat:@"-:-"]];
                [bDecline setTitle:@"FORFEIT" forState:UIControlStateNormal];
                /*[bDecline setBackgroundImage:nil forState:UIControlStateDisabled];
                [bDecline setBackgroundImage:nil forState:UIControlStateNormal];*/
                bDecline.enabled = NO;
                bDecline.alpha = 0.6;
            }else{
                [bDecline setTitle:@"RESULTS" forState:UIControlStateNormal];
                bDecline.enabled = NO;
                bDecline.alpha = 0.6;
            }
        }else{
            [bDecline addTarget:self action:@selector(openRoundDetail:) forControlEvents:UIControlEventTouchUpInside];
            [bDecline setTitle:@"RESULTS" forState:UIControlStateNormal];
        }        
        [challengeScroll addSubview:bDecline];
        
        
        // player first name label
        UILabel *lbName = [[UILabel alloc] initWithFrame:CGRectMake(75, 10+i*height, 180, 30)];
        lbName.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        lbName.backgroundColor = [UIColor clearColor];        
        [lbName setText:[NSString stringWithFormat:@"%@",player.fname]];
        //[lbName setText:[NSString stringWithFormat:@"%@",appDelegate.challenge_player_user_fname_array[i]]];
        [lbName setFont:[UIFont boldSystemFontOfSize:16]];
        [challengeScroll addSubview:lbName];
        
        // player last name label
        UILabel *lbType = [[UILabel alloc] initWithFrame:CGRectMake(75, 10+i*height+20, 180, 30)];
        lbType.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        lbType.backgroundColor = [UIColor clearColor];
        [lbType setText:[NSString stringWithFormat:@"%@", player.lname]];
        
        [lbType setFont:[UIFont boldSystemFontOfSize:16]];
        [challengeScroll addSubview:lbType];
        
        i++;
    }
    
}
- (void) gotoChallenge:(UIButton *)sender {
    // init challenge data
    appDelegate.challengePointer = sender.tag;
    appDelegate.genre = appDelegate.challenge_genre_type_array[appDelegate.challengePointer];
    appDelegate.game_id = [appDelegate.challenge_game_id_array[appDelegate.challengePointer] integerValue];
    appDelegate.gameplay_round = [appDelegate.gameplay_round_array[appDelegate.challengePointer] integerValue];
    
    NSString *status = appDelegate.gameplay_status[appDelegate.challengePointer];
    // if user is accepting a challenge
    if ([status isEqualToString:@"accept"]){
        
        // start genre starter
        GenreStarter *genreStarter = [[GenreStarter alloc] initWithNibName:@"GenreStarter" bundle:nil];
        appDelegate.challenge_type = @"challenge";
        
        navController = [[UINavigationController alloc] initWithRootViewController: genreStarter];
        [navController setNavigationBarHidden:YES];
        [self presentViewController:navController animated:YES completion:nil];
        
    // if user is starting new challenge or challenge back
    }else if ([status isEqualToString:@"start"]){
        User *player = appDelegate.challenge_player[appDelegate.challengePointer];
        appDelegate.uid_challenge_target = player.id;
        appDelegate.challenge_type = @"self";
        
        [self startMediaSelection];
    }
    
    
}

-(void)startMediaSelection {
    MediaSelection *mediaSelection = [[MediaSelection alloc] initWithNibName:@"MediaSelection" bundle:nil];
    navController = [[UINavigationController alloc] initWithRootViewController: mediaSelection];
    [navController setNavigationBarHidden:YES];
    [self presentViewController:navController animated:YES completion:nil];
    
}
- (void) openRoundDetail:(UIButton *) sender {
    appDelegate.challengePointer = sender.tag;
    appDelegate.game_id = [appDelegate.challenge_game_id_array[appDelegate.challengePointer] integerValue];
    
    RoundDetailResult *roundDetailResult = [[RoundDetailResult alloc] initWithNibName:@"RoundDetailResult" bundle:nil];    
    navController = [[UINavigationController alloc] initWithRootViewController: roundDetailResult];
    [navController setNavigationBarHidden:YES];
    
    [UIView beginAnimations:@"LeftFlip" context:nil];
    [UIView setAnimationDuration:0.8];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view.superview cache:YES];
    [UIView commitAnimations];    
    [self presentViewController:navController animated:NO completion:nil];
    
    
}
- (void) declineGameplay:(UIButton *) sender {
    appDelegate.challengePointer = sender.tag;
    
    // disable activities
    [self freeChallengeScroll];
    self.view.userInteractionEnabled = NO;
    pChallenges.hidden = NO;
    
    NSString *urlString = [NSString stringWithFormat:@"%@/service/getGameInfo.php?user_id=%d&remove_game_id=%d", appDelegate.BASE_URL, [appDelegate.user.id integerValue], [appDelegate.challenge_game_id_array[appDelegate.challengePointer] integerValue]];
    
    TBXML *xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:urlString] success:loadGameInfoSuccess failure:loadGameInfoFailure];
    
    xmlData = nil;
}

- (void) removeChallenge:(UIButton *) sender {
    
    
    
    appDelegate.challengePointer = sender.tag;
    User *player = appDelegate.challenge_player[appDelegate.challengePointer];
    appDelegate.player = [[User alloc] init];
   
    appDelegate.player.opponent_won = player.opponent_won;
    appDelegate.player.won = player.won;
    appDelegate.player.id = player.id;
    
    GameplayResult *gameplayResult = [[GameplayResult alloc] initWithNibName:@"GameplayResult" bundle:nil];
    navController = [[UINavigationController alloc] initWithRootViewController: gameplayResult];
    [navController setNavigationBarHidden:YES];
    
    [UIView beginAnimations:@"LeftFlip" context:nil];
    [UIView setAnimationDuration:0.8];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view.superview cache:YES];
    [UIView commitAnimations];
    [self presentViewController:navController animated:NO completion:nil];
    
    /*
    self.view.userInteractionEnabled = NO;
    pChallenges.hidden = NO;
    
    // load game info from server
    NSString *urlString = [NSString stringWithFormat:@"%@/removeChallenge.php?user_id=%d&challenge_id=%@", [appDelegate.user.id integerValue], appDelegate.challenge_id_array[sender.tag]];
    NSLog(@"aaa%@",urlString);
    TBXML *xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:urlString] success:loadGameInfoSuccess failure:loadGameInfoFailure];
    xmlData = nil;
     */
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    appDelegate = [[UIApplication sharedApplication] delegate];
        
    
    if ( [[UIDevice currentDevice].model hasPrefix:@"iPad"] ){
        NSLog(@"ipad");
        appDelegate.isHD = YES;
    }else{
        NSLog(@"iphone");
        appDelegate.isHD = NO;
    }
    
    // init the loading promo (load up front in order to block)
//    NSData *promoData = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://oskoui-interactive.com/projects/screenSlam/include/images/screenslam_loading_promo.jpg"]];
//    imgPromo = [[UIImageView alloc] initWithImage:[UIImage imageWithData:promoData]];
//    imgPromo.contentMode = UIViewContentModeScaleAspectFill;
//    imgPromo.clipsToBounds = YES;
//    imgPromo.frame = CGRectMake(0, 0, 320, 568);
//    [self.view addSubview:imgPromo];
//    imgPromo.hidden = YES;
    
    // fake the preloader
    if (!appDelegate.isHD && !([[UIScreen mainScreen] bounds].size.height-568)){
        preloaderPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"screenslam_iphone5_preloader.png"]];
        preloaderPanel.frame = CGRectMake(0, 0, 320, 568);
    }else{
        preloaderPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"screenslam_iphone4_preloader.png"]];
        preloaderPanel.frame = CGRectMake(0, 0, 320, 480);
    }
    preloaderPanel.contentMode = UIViewContentModeScaleAspectFill;
    preloaderPanel.clipsToBounds = YES;
    
    [self.view addSubview:preloaderPanel];
    // remove the preloader promo after 3 second
    [self performSelector:@selector(removePreloaderPanel) withObject:nil afterDelay:3];
    
    // display invisble terms button
    bTerms = [UIButton buttonWithType:UIButtonTypeCustom];
    bTerms.backgroundColor = [UIColor clearColor];
    [bTerms addTarget:self action:@selector(gotoTerms:) forControlEvents:UIControlEventTouchUpInside];
    if (!appDelegate.isHD && !([[UIScreen mainScreen] bounds].size.height-568)){
        bTerms.frame = CGRectMake(180, 520, 60, 40);
    }else{
        bTerms.frame = CGRectMake(180, 435, 60, 40);
    }    
    bTerms.alpha = 0.5;
    [self.view addSubview:bTerms];
    
    // display invisble privacy button
    bPrivacy = [UIButton buttonWithType:UIButtonTypeCustom];
    bTerms.backgroundColor = [UIColor clearColor];
    [bPrivacy addTarget:self action:@selector(gotoPrivacy:) forControlEvents:UIControlEventTouchUpInside];
    if (!appDelegate.isHD && !([[UIScreen mainScreen] bounds].size.height-568)){
        bPrivacy.frame = CGRectMake(240, 520, 60, 40);
    }else{
        bPrivacy.frame = CGRectMake(240, 435, 60, 40);
    }    
    bPrivacy.alpha = 0.5;
    [self.view addSubview:bPrivacy];
    
    
    // init environment
    
    appDelegate.FBChecked = NO;
    appDelegate.FBConnected = NO;
    // init background
	//self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"iphone_bg.jpg"]];
    // init the scroll content
    for (UIView *subview in challengeScroll.subviews){
        subview.tag = -1;
    }
    
    // init connection error handler
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(mainConnectionErrorAlert:) name:@"mainConnectionError" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectionErrorAlert:) name:@"connectionError" object:nil];
    // init the notification center
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayFBScreen:) name:@"displayFBScreen" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(initGame:) name:@"gameInfoLoaded" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadGameInfo:) name:@"reloadGameInfo" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(launchUserTypeSelection:) name:@"launchUserTypeSelection" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(launchMediaSelection:) name:@"launchMediaSelection" object:nil];
    
    //VVadded  moved image load to background, slow or no server will not stall launch
    [self performSelectorInBackground:@selector(loadImageInBackground) withObject:nil];
    
    //    // init the loading promo (load up front in order to block)
    //    NSData *promoData = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://oskoui-interactive.com/projects/screenSlam/include/images/screenslam_loading_promo.jpg"]];
    //    NSLog(@"[promoData length] = %d",[promoData length]);
    //    //if ([promoData length] != 0) {
    //    imgPromo = [[UIImageView alloc] initWithImage:[UIImage imageWithData:promoData]];
    //    imgPromo.contentMode = UIViewContentModeScaleAspectFill;
    //    imgPromo.clipsToBounds = YES;
    //    imgPromo.frame = CGRectMake(0, 0, 320, 568);
    //    imgPromo.hidden = YES;
    //    [self.view addSubview:imgPromo];
    
    
}


// VVadded
- (void) loadImageInBackground {
    NSLog(@"loadImageInBackground");
    
    // Retrieve the remote image
    NSURL *imgURL = [NSURL URLWithString:@"http://screenslam.foxfilm.com/include/images/screenslam_loading_promo.jpg"];
    NSData *imgData = [NSData dataWithContentsOfURL:imgURL];
    UIImage *img    = [[UIImage alloc] initWithData:imgData];
    
    // Image retrieved, call main thread method to update image, passing it the downloaded UIImage
    [self performSelectorOnMainThread:@selector(assignImageToImageView:) withObject:img waitUntilDone:YES];
}

//VVadded
- (void) assignImageToImageView:(UIImage *)img
{
    NSLog(@"assignImageToImageView");
    imgPromo = [[UIImageView alloc] initWithImage:img];
    imgPromo.contentMode = UIViewContentModeScaleAspectFill;
    imgPromo.clipsToBounds = YES;
    imgPromo.frame = CGRectMake(0, 0, 320, 568);
    imgPromo.hidden = YES;
    [self.view addSubview:imgPromo];    
}


-(void) gotoTerms:(UIButton *)sender {
    TermsScreen *termsScreen = [[TermsScreen alloc] initWithNibName:@"TermsScreen" bundle:nil];
    navController = [[UINavigationController alloc] initWithRootViewController: termsScreen];
    [navController setNavigationBarHidden:YES];
    [self presentViewController:navController animated:YES completion:nil];
}

-(void) gotoPrivacy:(UIButton *)sender {
    PrivacyScreen *privacyScreen = [[PrivacyScreen alloc] initWithNibName:@"PrivacyScreen" bundle:nil];
    navController = [[UINavigationController alloc] initWithRootViewController: privacyScreen];
    [navController setNavigationBarHidden:YES];
    [self presentViewController:navController animated:YES completion:nil];
}

-(void) removePreloaderPanel {
    
    [UIView animateWithDuration:1
                     animations:^{
                         preloaderPanel.alpha = 0.0;
                     }
                     completion:^(BOOL finished){
                         [preloaderPanel removeFromSuperview];
                     }];
    
    imgPromo.hidden = NO;
    bTerms.hidden = YES;
    bPrivacy.hidden = YES;
    
    [self performSelector:@selector(removeLoadingPromo) withObject:nil afterDelay:3];
}

-(void) removeLoadingPromo {
    [UIView animateWithDuration:1
                     animations:^{
                         imgPromo.alpha = 0.0;
                     }
                     completion:^(BOOL finished){
                         [imgPromo removeFromSuperview];
                     }];
}

-(void) viewDidAppear:(BOOL)animated {
    
    
    if (!appDelegate.FBChecked){
        
        // simulate fb and on-fb users
        /*NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:@"101" forKey:@"uid"];
        [FBSession.activeSession closeAndClearTokenInformation];*/
        //[appDelegate openSession];
        
        
        appDelegate.user = [[User alloc] init];
        
        // check facbeook session and choose the view
        if (FBSession.activeSession.state == FBSessionStateCreatedTokenLoaded) {
            
            // LOGIN ALREADY
            NSLog(@"fb session detect");
            
            /*
            // create newuser account
            [[FBRequest requestForMe] startWithCompletionHandler:
             ^(FBRequestConnection *connection,
               NSDictionary<FBGraphUser> *user,
               NSError *error) {
                 NSLog(@"rrrr");
                 if (!error) {
                     NSLog(@"start ttt");
                     appDelegate.user_id = 0;
                     appDelegate.user_fid = user.id;
                     appDelegate.user_fname = user.first_name;
                     appDelegate.user_lname = user.last_name;
                     appDelegate.user_thumbnail = [NSString stringWithFormat:@"http://graph.facebook.com/%@/picture?type=large",user.id];
                     
                     NSLog(@"ttttt%d",appDelegate.user_id);
                     [self loadGameInfo];
                     
                 }else{
                     
                     appDelegate.FBChecked = NO;
                     appDelegate.FBConnected = NO;
                 }
             }];*/
            [appDelegate openSession];
    
            
        } else {
            
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            
            // if uid exist, then start the game by the existing user id
            if ([defaults objectForKey:@"uid"] != NULL){
                appDelegate.FBChecked = YES;
                
                appDelegate.user.id = [defaults objectForKey:@"uid"];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGameInfo" object:nil];
                
                // if uid not exist, then either login into fb or create a new user
            }else{
                NSLog(@"no uid exist, choose fb/non-fb user");
                [[NSNotificationCenter defaultCenter] postNotificationName:@"displayFBScreen" object:nil];
            }
        }
    }
    // If iPad is on cellular connection, throw alert once and only once.
    if ( [[UIDevice currentDevice].model hasPrefix:@"iPad"] ){
        Reachability *reachability = [Reachability reachabilityForInternetConnection];
        [reachability startNotifier];
        
        NetworkStatus status = [reachability currentReachabilityStatus];
        
        if(status == NotReachable)
        {
            NSLog(@"Reachability -- No internet");
        }
        else if (status == ReachableViaWiFi)  //WiFi
        {
            NSLog(@"Reachability -- WiFi");
        }
        else if (status == ReachableViaWWAN)  //3G
        {
            NSLog(@"Reachability -- WAN");
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            if ([defaults boolForKey:@"WANAlertHasBeenShown"]==NO) {
                [defaults setBool:YES forKey:@"WANAlertHasBeenShown"];
                NSString *message = [NSString stringWithFormat:@"For the best experience activate WiFi!"];
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"NOTICE"
                                                                message:message
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles: nil];
                [alert show];
            }
        }
    }
}

-(void)showFBConnectScreen {
    FacebookLogin *facebookLogin = [[FacebookLogin alloc] initWithNibName:@"FacebookLogin" bundle:nil];
    UINavigationController *fbViewController = [[UINavigationController alloc] initWithRootViewController: facebookLogin];
    [fbViewController setNavigationBarHidden:YES];
    [self presentViewController:fbViewController animated:NO completion:nil];
}

-(void) loadGameInfo {
    [self freeChallengeScroll];
    self.view.userInteractionEnabled = NO;
    pChallenges.hidden = NO;
    
    // load game info from server
    NSString *urlString;
        
    // if user id is available
    if ([appDelegate.user.id integerValue] != 0){
        urlString = [NSString stringWithFormat:@"%@/service/getGameInfo.php?user_id=%d", appDelegate.BASE_URL, [appDelegate.user.id integerValue]];
    // if the user id is not available
    }else{
        urlString = [NSString stringWithFormat:@"%@/service/getGameInfo.php?user_id=0&fid=%@&fname=%@&lname=%@&thumbnail=%@", appDelegate.BASE_URL, appDelegate.user.fid, appDelegate.user.fname, appDelegate.user.lname, appDelegate.user.thumbnail];
    }
    
    NSLog(@"get gameinfo %@",urlString);
    TBXML *xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:urlString] success:loadGameInfoSuccess failure:loadGameInfoFailure];
    
    xmlData = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)gotoMediaSelection:(id)sender {
    [self startUserTypeSelection];

}

-(void)startUserTypeSelection {
    appDelegate.game_id = 0;
    appDelegate.challenge_type = @"self";
    appDelegate.gameplay_round = 1;
    
    ChoosePlayerType *choosePlayerType = [[ChoosePlayerType alloc] initWithNibName:@"ChoosePlayerType" bundle:nil];
    navController = [[UINavigationController alloc] initWithRootViewController: choosePlayerType];
    
    [navController setNavigationBarHidden:YES];
    [self presentViewController:navController animated:YES completion:nil];
}

- (IBAction)changeFBConnect:(id)sender {
    // if it is facebook connected, then logout the user
    if (appDelegate.FBConnected){
        // clear fb session
        [FBSession.activeSession closeAndClearTokenInformation];
        appDelegate.FBConnected = NO;
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        
        // if uid exist, then start the game by the existing user id
        if ([defaults objectForKey:@"uid"] != NULL){
            
            appDelegate.user.id = [defaults objectForKey:@"uid"];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGameInfo" object:nil];
            
            // if uid not exist, then either login into fb or create a new user
        }else{
            [[NSNotificationCenter defaultCenter] postNotificationName:@"displayFBScreen" object:nil];
        }
    
    // if it is not facebook connected, then login the user
    }else{
        [appDelegate openSession];
    }
}

- (IBAction)refreshGameInfo:(id)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGameInfo" object:nil];
}

- (IBAction)gotoHelpScreen:(id)sender {
    HelpScreen *helpScreen = [[HelpScreen alloc] initWithNibName:@"HelpScreen" bundle:nil];
    navController = [[UINavigationController alloc] initWithRootViewController: helpScreen];
    [navController setNavigationBarHidden:YES];
    [self presentViewController:navController animated:YES completion:nil];
}
- (IBAction)testUser:(UIButton *)sender {
    //appDelegate.user.id = sender.tag;
    
    //[self loadGameInfo];
}


@end
