//
//  RoundDetailResult.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/8/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import "RoundDetailResult.h"
#import "TBXML+HTTP.h"

@interface RoundDetailResult ()

@end

@implementation RoundDetailResult
@synthesize appDelegate;
@synthesize  mediaScroll;
@synthesize pbRound;


// static function that handle xml parsing
TBXMLFailureBlock getLastRoundfailureBlock = ^(TBXML *tbxmlDocument, NSError * error) {
    NSLog(@"Error! %@ %@", [error localizedDescription], [error userInfo]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionError" object:nil];
};

TBXMLSuccessBlock getLastRoundsuccessBlock = ^(TBXML *tbxmlDocument) {
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.round_user_time_array = [[NSMutableArray alloc] init];
    appDelegate.round_player_time_array = [[NSMutableArray alloc] init];
    appDelegate.round_name_array = [[NSMutableArray alloc] init];
    appDelegate.round_etailer_array = [[NSMutableArray alloc] init];
    appDelegate.round_thumbnail_array = [[NSMutableArray alloc] init];
    
    TBXMLElement *rootElement = tbxmlDocument.rootXMLElement;
    
    TBXMLElement *media = [TBXML childElementNamed:@"media" parentElement:rootElement];
    //TBXMLElement *media = [TBXML childElementNamed:@"elapsed" parentElement:medias];
    while (media != nil){
        TBXMLElement *media_name = [TBXML childElementNamed:@"media_name" parentElement:media];        
        NSString *tempString = [[TBXML textForElement:media_name] stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
        tempString = [tempString stringByReplacingOccurrencesOfString:@"&#x92;" withString:@"'"];
        [appDelegate.round_name_array addObject:tempString];
        
        TBXMLElement *media_etailer = [TBXML childElementNamed:@"media_etailer" parentElement:media];
        [appDelegate.round_etailer_array addObject:[TBXML textForElement:media_etailer]];
        TBXMLElement *media_thumbnail = [TBXML childElementNamed:@"media_thumbnail" parentElement:media];
        [appDelegate.round_thumbnail_array addObject:[TBXML textForElement:media_thumbnail]];
        
        media = [TBXML nextSiblingNamed:@"media" searchFromElement:media];
        
    }
    
    
    TBXMLElement *player_times = [TBXML childElementNamed:@"player" parentElement:rootElement];
    TBXMLElement *player_time = [TBXML childElementNamed:@"elapsed" parentElement:player_times];
    while (player_time != nil){
        [appDelegate.round_player_time_array addObject:[TBXML textForElement:player_time]];
        player_time = [TBXML nextSiblingNamed:@"elapsed" searchFromElement:player_time];
        
    }
    
    TBXMLElement *user_times = [TBXML childElementNamed:@"user" parentElement:rootElement];
    TBXMLElement *user_time = [TBXML childElementNamed:@"elapsed" parentElement:user_times];    
    while (user_time != nil){        
        [appDelegate.round_user_time_array addObject:[TBXML textForElement:user_time]];
        user_time = [TBXML nextSiblingNamed:@"elapsed" searchFromElement:user_time];
        
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RoundDetailLoaded" object:nil];
    
};

-(void)displayRoundDetail:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(displayRoundDetailInMain) withObject:nil waitUntilDone:YES];
    
}

-(void)displayRoundDetailInMain {
    pbRound.hidden = YES;
    
    // display detail results
    double height = 60+8;
    [mediaScroll flashScrollIndicators];
    [mediaScroll setScrollEnabled:YES];
    [mediaScroll setContentSize:CGSizeMake(260, 10+5*height+88)];
    int j = 0;
    while (j < [appDelegate.round_name_array count]) {
        // image panel
        UIImageView *imgPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"panel_challengeboard_yellow.png"]];        
        imgPanel.frame = CGRectMake(8, 10+j*height, 266, 60);
        [mediaScroll addSubview:imgPanel];
        
        // media thumbnail panel
        UIImageView *mediaPanel;
        if ([appDelegate.round_thumbnail_array[j] isEqualToString:@"default"]){
            mediaPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"default_fox_title.png"]];
            NSLog(@"defaultttt fox image");
        }else{
            NSData *mediaTNData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@", appDelegate.BASE_URL, appDelegate.round_thumbnail_array[j]]]];
            mediaPanel = [[UIImageView alloc] initWithImage:[UIImage imageWithData:mediaTNData]];
            NSLog(@"defaultttt fox image : %@",appDelegate.round_thumbnail_array[j]);
        }        
        mediaPanel.frame = CGRectMake(8+15, 10+j*height+5, 50, 50);
        [mediaScroll addSubview:mediaPanel];
        
        // user display
        UIImageView *imgUserPanel = [[UIImageView alloc] initWithImage:appDelegate.imgUserData];
        imgUserPanel.frame = CGRectMake(175, 10+j*height+5, 40, 40);
        imgUserPanel.contentMode = UIViewContentModeScaleAspectFill;
        imgUserPanel.clipsToBounds = YES;
        [mediaScroll addSubview:imgUserPanel];
        
        // user  border
        UIImageView *imgUserBorder = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"profileBorder.png"]];
        imgUserBorder.frame = CGRectMake(174, 10+j*height+4, 42, 42);
        imgUserBorder.contentMode = UIViewContentModeScaleAspectFill;
        imgUserBorder.clipsToBounds = YES;
        [mediaScroll addSubview:imgUserBorder];        
        
        // player display
        User *player = appDelegate.challenge_player[appDelegate.challengePointer];
        NSData *playerPanelData = [NSData dataWithContentsOfURL:[NSURL URLWithString:player.thumbnail]];
        UIImageView *imgPlayerPanel = [[UIImageView alloc] initWithImage:[UIImage imageWithData:playerPanelData]];
        imgPlayerPanel.frame = CGRectMake(225, 10+j*height+5, 40, 40);
        imgPlayerPanel.contentMode = UIViewContentModeScaleAspectFill;
        imgPlayerPanel.clipsToBounds = YES;
        [mediaScroll addSubview:imgPlayerPanel];
        
        // player border
        UIImageView *imgPlayerBorder = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"profileBorder.png"]];
        imgPlayerBorder.frame = CGRectMake(224, 10+j*height+4, 42, 42);
        imgPlayerBorder.contentMode = UIViewContentModeScaleAspectFill;
        imgPlayerBorder.clipsToBounds = YES;
        [mediaScroll addSubview:imgPlayerBorder];
                
        // BUY NOW button
        UIButton *m = [UIButton buttonWithType:UIButtonTypeCustom];
        m.tag = j;
        [m setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateNormal];
        [m setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateDisabled];
        m.backgroundColor = [UIColor clearColor];
        [m addTarget:self action:@selector(gotoURL:) forControlEvents:UIControlEventTouchUpInside];
        m.frame = CGRectMake(71, 10+j*height+30, 75, 22);
        [m setTitle:@"BUY NOW" forState:UIControlStateNormal];
        [m.titleLabel setFont:[UIFont boldSystemFontOfSize:12]];
        [mediaScroll addSubview:m];
        if ([appDelegate.round_etailer_array[j] isEqualToString:@"none"]){
            m.enabled = NO;
            m.alpha = 0.6;
        }
        
        
        // MEDIA NAME LABEL
        UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(80, 10+j*height+6, 90, 30)];
        l.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        l.backgroundColor = [UIColor clearColor];
        [l setLineBreakMode:NSLineBreakByWordWrapping];
        l.numberOfLines = 2;
        [l setText:appDelegate.round_name_array[j]];
        [l setFont:[UIFont boldSystemFontOfSize:10]];
        [mediaScroll addSubview:l];
        
        // YOUR SCORE label
        UILabel *lbUserScore = [[UILabel alloc] initWithFrame:CGRectMake(170, 10+j*height+37, 50, 30)];
        lbUserScore.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        lbUserScore.textAlignment = NSTextAlignmentCenter;
        lbUserScore.backgroundColor = [UIColor clearColor];
        if ([appDelegate.round_user_time_array[j] doubleValue] == -1){
            [lbUserScore setFont:[UIFont boldSystemFontOfSize:7]];
            lbUserScore.textColor = [UIColor colorWithRed:162/255.f green:19/255.f blue:19/255.f alpha:255/255.f];
            [lbUserScore setText:[NSString stringWithFormat:@"WRONG"]];
            [imgUserPanel setAlpha:0.5];
            imgUserBorder.hidden = YES;
        }else{
            [lbUserScore setFont:[UIFont boldSystemFontOfSize:7]];
            [lbUserScore setText:[NSString stringWithFormat:@"%.2fs",[appDelegate.round_user_time_array[j] doubleValue]]];
            
        }        
        [mediaScroll addSubview:lbUserScore];
        
        // PLAYER SCORE LABEL
        UILabel *lbPlayerScore = [[UILabel alloc] initWithFrame:CGRectMake(218, 10+j*height+37, 50, 30)];
        lbPlayerScore.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        lbPlayerScore.textAlignment = NSTextAlignmentCenter;
        lbPlayerScore.backgroundColor = [UIColor clearColor];
        if ([appDelegate.round_player_time_array[j] doubleValue] == -1){
            [lbPlayerScore setFont:[UIFont boldSystemFontOfSize:7]];
            lbPlayerScore.textColor = [UIColor colorWithRed:162/255.f green:19/255.f blue:19/255.f alpha:255/255.f];
            [lbPlayerScore setText:[NSString stringWithFormat:@"WRONG"]];
            [imgPlayerPanel setAlpha:0.5];
            imgPlayerBorder.hidden = YES;
        }else{
            [lbPlayerScore setFont:[UIFont boldSystemFontOfSize:7]];
            [lbPlayerScore setText:[NSString stringWithFormat:@"%.2fs",[appDelegate.round_player_time_array[j] doubleValue]]];
        }
        if ([appDelegate.round_user_time_array[j] doubleValue] != -1 && [appDelegate.round_user_time_array[j] doubleValue] < [appDelegate.round_player_time_array[j] doubleValue]){
            [imgPlayerPanel setAlpha:0.5];
            imgPlayerBorder.hidden = YES;
        }else if ([appDelegate.round_player_time_array[j] doubleValue] != -1 && [appDelegate.round_user_time_array[j] doubleValue] > [appDelegate.round_player_time_array[j] doubleValue]){
            [imgUserPanel setAlpha:0.5];
            imgUserBorder.hidden = YES;
        }
        [mediaScroll addSubview:lbPlayerScore];
        
        j++;
    }

}

- (void) gotoURL:(UIButton *)sender {
    NSLog(@"url: %@",appDelegate.round_etailer_array[sender.tag]);
    if (![appDelegate.etailers[sender.tag] isEqualToString:@"none"]){
        [[UIApplication sharedApplication] openURL:[[NSURL alloc] initWithString:appDelegate.round_etailer_array[sender.tag]]];
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    NSLog(@"game id %d", appDelegate.game_id);
    
    // add listeners
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayRoundDetail:) name:@"RoundDetailLoaded" object:nil];
    
    // display past result
    TBXML *xmlData;
    xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/getRoundDetail.php?game_id=%d&user_id=%d", appDelegate.BASE_URL, appDelegate.game_id, [appDelegate.user.id integerValue]]] success:getLastRoundsuccessBlock failure:getLastRoundfailureBlock];
    xmlData = nil;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)closeResult:(id)sender {
    [UIView beginAnimations:@"LeftFlip" context:nil];
    [UIView setAnimationDuration:0.8];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.navigationController.view.superview cache:YES];
    [UIView commitAnimations];
    [self.navigationController dismissViewControllerAnimated:NO completion:nil];
    
}

@end
