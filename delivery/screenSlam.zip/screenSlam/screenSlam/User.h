//
//  User.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/3/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject {
    NSString *id;
    NSString *fid;
    NSString *fname;
    NSString *lname;
    NSString *thumbnail;
    NSInteger score;
    // extra
    NSInteger game_score;
    NSInteger won;
    NSInteger opponent_won;
    NSMutableArray *timeSpends;
}

@property (nonatomic,retain) NSString * id;
@property (nonatomic,retain) NSString * fid;
@property (nonatomic,retain) NSString * fname;
@property (nonatomic,retain) NSString * lname;
@property (nonatomic,retain) NSString * thumbnail;
@property (nonatomic) NSInteger score;

@property (nonatomic) NSInteger game_score;
@property (nonatomic) NSInteger won;
@property (nonatomic) NSInteger opponent_won;
@property (nonatomic,retain) NSMutableArray *timeSpends;

@end
