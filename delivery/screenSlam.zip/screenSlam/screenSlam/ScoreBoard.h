//
//  ScoreBoard.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ScoreBoard : UIViewController {
    AppDelegate *appDelegate;
}

@property (nonatomic, retain) AppDelegate *appDelegate;
@property (strong, nonatomic) IBOutlet UILabel *txtTime;
@property (strong, nonatomic) IBOutlet UILabel *txtScore;
@property (strong, nonatomic) IBOutlet UILabel *txtCorrectChoice;
@property (strong, nonatomic) IBOutlet UIImageView *imgResult;

@end
