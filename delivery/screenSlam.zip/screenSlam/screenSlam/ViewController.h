//
//  ViewController.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"


@interface ViewController : UIViewController {
    AppDelegate *appDelegate;
    
    UIButton *bTerms;
    UIButton *bPrivacy;
    
    UIImageView *imgPromo;
    UIImageView *preloaderPanel;
    
    NSURLConnection *connect;
    NSMutableData *tempData;
    NSMutableURLRequest *request;
    
    UINavigationController *navController;
}
@property (nonatomic, retain) AppDelegate *appDelegate;

@property (strong, nonatomic) UIButton *bTerms;
@property (strong, nonatomic) UIButton *bPrivacy;

- (IBAction)testUser:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIImageView *imgInstruction;

@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *pChallenges;
@property (nonatomic, retain) UIImageView *imgPromo;
@property (nonatomic, retain) UIImageView *preloaderPanel;

@property (nonatomic, retain) NSURLConnection *connect;
@property (nonatomic, retain) NSMutableData *tempData;
@property (nonatomic, retain) NSMutableURLRequest *request;

@property (strong, nonatomic) IBOutlet UILabel *txtFName;
@property (strong, nonatomic) IBOutlet UIButton *bStart;
@property (strong, nonatomic) IBOutlet UIImageView *imgProfile;
@property (strong, nonatomic) IBOutlet UILabel *txtScore;
@property (strong, nonatomic) IBOutlet UILabel *txtUID;
@property (strong, nonatomic) IBOutlet UIButton *bFBConnet;

@property (strong, nonatomic) IBOutlet UINavigationController *navController;

@property (strong, nonatomic) IBOutlet UIScrollView *challengeScroll;

- (IBAction)gotoMediaSelection:(id)sender;
- (IBAction)changeFBConnect:(id)sender;
- (IBAction)refreshGameInfo:(id)sender;
- (IBAction)gotoHelpScreen:(id)sender;


@end
