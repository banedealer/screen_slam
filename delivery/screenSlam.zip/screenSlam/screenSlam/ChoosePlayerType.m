//
//  ChoosePlayerType.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/12/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "ChoosePlayerType.h"
#import "TBXML+HTTP.h"
#import "MediaSelection.h"
#import "PickUserByID.h"

@interface ChoosePlayerType () <FBViewControllerDelegate>

@end

@implementation ChoosePlayerType
@synthesize appDelegate;
@synthesize friendPickerController;
@synthesize bFacebook,bRandom,bUser;

// static function that handle xml parsing
TBXMLFailureBlock checkFBUIDFailure = ^(TBXML *tbxmlDocument, NSError * error) {
    NSLog(@"Error! %@ %@", [error localizedDescription], [error userInfo]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionError" object:nil];
};

TBXMLSuccessBlock checkFBUIDSuccess = ^(TBXML *tbxmlDocument) {
    
    
    TBXMLElement *rootElement = tbxmlDocument.rootXMLElement;
    TBXMLElement *valid = [TBXML childElementNamed:@"valid" parentElement:rootElement];
    NSString *validResult= [TBXML textForElement:valid];
    
    NSLog(@"responsee from check uid %@ %@", [TBXML textForElement:valid], validResult);
    
    if ([validResult isEqualToString:@"2"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"existFBAlert" object:nil];
    }else if ([validResult isEqualToString:@"1"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"validFBAction" object:nil];
    }
    
};

-(void)existAlert:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(existAlertInMain) withObject:nil waitUntilDone:YES];
}
-(void)validAction:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(validActionInMain) withObject:nil waitUntilDone:YES];
}
-(void)validActionInMain{
    self.view.userInteractionEnabled = YES;
    [friendPickerController dismissViewControllerAnimated:NO completion:Nil];
    MediaSelection *mediaSelection = [[MediaSelection alloc] initWithNibName:@"MediaSelection" bundle:nil];
    [self.navigationController pushViewController:mediaSelection animated:YES];
}

-(void)existAlertInMain {
    // free FB target
    appDelegate.fb_challenge_target = nil;
    
    self.view.userInteractionEnabled = YES;
    [friendPickerController dismissViewControllerAnimated:YES completion:Nil];
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Oops!"
                              message:@"Sorry! You are already playing with that player."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
    [alertView show];
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // init
    appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.fb_challenge_target_fname = @"";
    appDelegate.fb_challenge_target_lname = @"";
    appDelegate.fb_challenge_target = nil;
    appDelegate.uid_challenge_target = nil;
    
    // pan gesture
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [panGesture setMaximumNumberOfTouches:1];
    [self.view addGestureRecognizer:panGesture];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(existAlert:) name:@"existFBAlert" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(validAction:) name:@"validFBAction" object:nil];
    
    // if the user is not connected to fb, then hide the fb and user id option
    if ([appDelegate.user.fid isEqualToString:@"0"]){
        bFacebook.alpha = 0.5;
        bUser.alpha = 0.5;
        bFacebook.enabled = NO;
        bUser.enabled = NO;
    }
}

//VVchanged
- (void)handlePan:(UIPanGestureRecognizer*)recognizer {
    
    CGPoint translation = [recognizer translationInView:recognizer.view];
    if (translation.x > 2) {
        
        //        [UIView beginAnimations:@"LeftFlip" context:nil];
        //        [UIView setAnimationDuration:0.8];
        //        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        //        [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.navigationController.view.superview cache:YES];
        //        [UIView commitAnimations];
        //        [self.navigationController dismissViewControllerAnimated:NO completion:nil];
        
        [self.navigationController dismissViewControllerAnimated:YES completion:^{ }];
    }
}

// Pick Friends button handler
- (IBAction)pickFriendsClick:(UIButton *)sender {
    friendPickerController = [[FBFriendPickerViewController alloc] init];
    friendPickerController.title = @"Pick Friends";
    [friendPickerController loadData];
    friendPickerController.delegate = self;
    
    // Use the modal wrapper method to display the picker.
    [friendPickerController presentModallyFromViewController:self animated:YES handler:
     ^(FBViewController *sender, BOOL donePressed) {
         /*if (!donePressed) {
             return;
         }
         
         if (friendPickerController.selection.count == 0) {
             [[[UIAlertView alloc] initWithTitle:@"You didn't select anyone!" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]
              show];
         } else {
             
             for (id<FBGraphUser> user in friendPickerController.selection) {
                 appDelegate.fb_challenge_target = user.id;
                 
                 break;
             }
             MediaSelection *mediaSelection = [[MediaSelection alloc] initWithNibName:@"MediaSelection" bundle:nil];
             [self.navigationController pushViewController:mediaSelection animated:YES];
         }*/
         
         
     }];
}

- (void)friendPickerViewControllerSelectionDidChange:(FBFriendPickerViewController *)friendPicker
{
    //self.view.userInteractionEnabled = NO;
    
    for (id<FBGraphUser> user in friendPicker.selection) {
        appDelegate.fb_challenge_target = user.id;
        appDelegate.fb_challenge_target_fname = user.first_name;
        appDelegate.fb_challenge_target_lname = user.last_name;
        
        NSString *urlString = [NSString stringWithFormat:@"%@/service/checkUID.php?user_id=%@&player_id=%@&fb=1", appDelegate.BASE_URL, appDelegate.user.id, user.id];
        NSLog(@"url:%@",urlString);
        TBXML *xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:urlString] success:checkFBUIDSuccess failure:checkFBUIDFailure];
        xmlData = nil;
        
        NSLog(@"%@ %@", appDelegate.fb_challenge_target_fname, appDelegate.fb_challenge_target_fname);
        
        /*
        NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Screen Slam", @"title", @"Someone invite you to play screen slam.", @"message", appDelegate.fb_challenge_target, @"to", nil];        
        [appDelegate.facebook dialog:@"apprequests" andParams:params andDelegate:nil];
        */
        break;
    }
    
    
    
    
}

- (IBAction)pickUserClick:(id)sender {
    PickUserByID *pickUserByID = [[PickUserByID alloc] initWithNibName:@"PickUserByID" bundle:nil];
    [self.navigationController pushViewController:pickUserByID animated:YES];
}
- (IBAction)pickRandomsClick:(UIButton *)sender {
    MediaSelection *mediaSelection = [[MediaSelection alloc] initWithNibName:@"MediaSelection" bundle:nil];
    [self.navigationController pushViewController:mediaSelection animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
