//
//  MediaSelection.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "MediaSelection.h"
#import "GenreStarter.h"

@interface MediaSelection ()

@end

@implementation MediaSelection 
@synthesize appDelegate;
@synthesize genreLoader;
@synthesize genreScroll;
@synthesize bPromo,g0,g1,g2,g3;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // init 
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"iphone_bg.jpg"]];
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    // pan gesture
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [panGesture setMaximumNumberOfTouches:1];
    [self.view addGestureRecognizer:panGesture];
    
    // hide preloader
    genreLoader.hidden = YES;
    
    // set genre scroll view
    [genreScroll flashScrollIndicators];
    [genreScroll setScrollEnabled:YES];
    [genreScroll setContentSize:CGSizeMake(320,568)];
    
    // unlocking genre
    g0.enabled = appDelegate.user.score > 100000 ? YES : NO;
    g1.enabled = appDelegate.user.score > 250000 ? YES : NO;
    g2.enabled = appDelegate.user.score > 375000 ? YES : NO;
    g3.enabled = appDelegate.user.score > 500000 ? YES : NO;
    
    // unlocking promo genre
    if (![appDelegate.promo_name isEqualToString:@""]){
        bPromo.hidden = NO;
        [bPromo setTitle:appDelegate.promo_name forState:UIControlStateNormal];
    }
    
}

- (void)handlePan:(UIPanGestureRecognizer*)recognizer {
    
    CGPoint translation = [recognizer translationInView:recognizer.view];
    if (translation.x > 2) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}


- (IBAction)generatePromoMedia:(id)sender {
    [self generateMedia:@"promo"];
}
- (IBAction)generateDramaMedia:(id)sender {
    [self generateMedia:@"drama"];
}
- (IBAction)generateComedyMedia:(id)sender {
    [self generateMedia:@"comedy"];
}
- (IBAction)generateScifiMedia:(id)sender {
    [self generateMedia:@"scifi"];    
}
- (IBAction)generateActionMedia:(id)sender {
    [self generateMedia:@"action"];
}
- (IBAction)generateHorrorMedia:(id)sender {
    [self generateMedia:@"horror"];
}
- (IBAction)generateFamilyMedia:(id)sender {
    [self generateMedia:@"family"];
}
- (IBAction)generateAllMedia:(id)sender {
    [self generateMedia:@"all"];
}

- (void) generateMedia:(NSString *)type {
    // show preloader
    genreLoader.hidden = NO;
    
    // load genre starter
    appDelegate.genre = [[NSString alloc] initWithString:type];
    GenreStarter *genreStarter = [[GenreStarter alloc] initWithNibName:@"GenreStarter" bundle:nil];
    [self.navigationController pushViewController:genreStarter animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
