//
//  GenreStarter.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface GenreStarter : UIViewController {
    AppDelegate *appDelegate;
    
    BOOL xmlReady;
    
    NSURLConnection *connect;
    NSMutableData *tempData;
    NSMutableURLRequest *request;
}

@property (nonatomic, retain) AppDelegate *appDelegate;
@property (nonatomic) BOOL xmlReady;

@property (nonatomic, retain) NSURLConnection *connect;
@property (nonatomic, retain) NSMutableData *tempData;
@property (nonatomic, retain) NSMutableURLRequest *request;

@property (strong, nonatomic) IBOutlet UIImageView *imgGenre;

@property (strong, nonatomic) IBOutlet UIImageView *imgUser;
@property (strong, nonatomic) IBOutlet UIImageView *imgPlayer;
@property (strong, nonatomic) IBOutlet UILabel *txtUser;
@property (strong, nonatomic) IBOutlet UILabel *txtUserScore;
@property (strong, nonatomic) IBOutlet UILabel *txtPlayer;
@property (strong, nonatomic) IBOutlet UILabel *txtPlayerScore;

@property (strong, nonatomic) IBOutlet UILabel *txtPoint;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *pLoader;


@end
