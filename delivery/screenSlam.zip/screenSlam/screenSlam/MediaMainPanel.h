//
//  MediaMainPanel.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import "AppDelegate.h"

@interface MediaMainPanel : UIViewController {
    AppDelegate *appDelegate;
    IBOutlet UIImageView *mediaMask;
    IBOutlet UIImageView *legalImageView;
    
    NSTimer *timer;
    
    NSURLConnection *connect;
    NSMutableData *tempData;
    NSMutableURLRequest *request;
    
    NSInteger correctPointer;
    
    NSDate *startTime;
    UIImageView *imagePlayer;
    MPMoviePlayerViewController *player;
    MPMoviePlayerViewController *soundWaveDisplay;
    AVPlayer *soundPlayer;
    
    IBOutlet UIActivityIndicatorView *pMedia;
    BOOL mediaPlayBackComplete;
}
@property (strong, nonatomic) IBOutlet UIImageView *imgCorrect;
@property (strong, nonatomic) IBOutlet UIImageView *imgWrong;


@property (nonatomic, retain) AppDelegate *appDelegate;

@property (strong, nonatomic) IBOutlet UIImageView *mediaMask;

@property (nonatomic, retain) NSTimer *timer;

@property (nonatomic, retain) NSURLConnection *connect;
@property (nonatomic, retain) NSMutableData *tempData;
@property (nonatomic, retain) NSMutableURLRequest *request;

@property (nonatomic) NSInteger correctPointer;

@property (nonatomic) BOOL mediaPlayBackComplete;
@property (strong, nonatomic) IBOutlet UIImageView *imgIcon;

@property (nonatomic, strong) NSDate *startTime;
@property (strong, nonatomic) IBOutlet UIImageView *imagePlayer;
@property (nonatomic, strong) MPMoviePlayerViewController *player;
@property (nonatomic, strong) MPMoviePlayerViewController *soundWaveDisplay;
@property (nonatomic, strong) AVPlayer *soundPlayer;

@property (strong, nonatomic) IBOutlet UIImageView *imgQuestion;
@property (strong, nonatomic) IBOutlet UILabel *q;
@property (strong, nonatomic) IBOutlet UIButton *b0;
@property (strong, nonatomic) IBOutlet UIButton *b1;
@property (strong, nonatomic) IBOutlet UIButton *b2;
@property (strong, nonatomic) IBOutlet UIButton *b3;
@property (strong, nonatomic) IBOutlet UIProgressView *elapsedBar;
@property (strong, nonatomic) IBOutlet UILabel *txtScore;

@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *pMedia;

- (IBAction)optionSelected:(UIButton *)sender;

@end
