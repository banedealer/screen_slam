//
//  AppDelegate.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import <FacebookSDK/FacebookSDK.h>
#import "Facebook.h"
#import "User.h"

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate> {
    NSString *BASE_URL;
    
    BOOL isHD;
    
    NSString *deviceToken;
    
    NSInteger videoPointer;
    NSInteger game_id;
    NSInteger gameplay_round;
    
    Facebook *facebook;
    BOOL FBConnected;
    BOOL FBChecked;
    
    NSString *genre;
    NSInteger challengePointer;
    NSString *fb_challenge_target;
    NSString *fb_challenge_target_fname;
    NSString *fb_challenge_target_lname;
    NSString *uid_challenge_target;
    
    UIImage *imgUserData;
    UIImage *imgPlayerData;
    
    NSString *promo_name;
    
    User *user;
    User *player;
    
    NSString *correctChoice;
    NSMutableArray *mediaType;
    NSMutableArray *mediaURLs;
    NSMutableArray *mediaLegals;
    NSMutableArray *mediaTNs;
    NSMutableArray *etailers;
    NSMutableArray *mediaNames;
    NSMutableArray *questions;
    NSMutableArray *choices;
    
    // information of each duel
    NSMutableArray *media_id_array;
    NSMutableArray *choice_var_array;
    NSMutableArray *timeSpends;
    NSMutableArray *durations;

    
    // challengers list
    NSString *challenge_type;
    NSMutableArray *gameplay_status;
    NSMutableArray *gameplay_round_array;
    NSMutableArray *challenge_game_id_array;
    NSMutableArray *challenge_id_array;
    NSMutableArray *challenge_genre_type_array;
    NSMutableArray *challenge_player;
    
    NSMutableArray *history_array;
    
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;

- (void)openSession;
- (void)sessionStateChanged:(FBSession *)session state:(FBSessionState) state error:(NSError *)error;

@property (nonatomic) NSString *BASE_URL;

@property (nonatomic) BOOL isHD;

@property (nonatomic, retain) NSString* deviceToken;

@property (nonatomic) NSInteger videoPointer;
@property (nonatomic) NSInteger game_id;
@property (nonatomic) NSInteger gameplay_round;

@property (nonatomic, retain) NSString *promo_name;

@property (nonatomic, retain) NSString *genre;
@property (nonatomic) NSInteger challengePointer;
@property (nonatomic, retain) NSString *fb_challenge_target_fname;
@property (nonatomic, retain) NSString *fb_challenge_target_lname;
@property (nonatomic, retain) NSString *fb_challenge_target;
@property (nonatomic, retain) NSString *uid_challenge_target;

@property (nonatomic, retain) UIImage *imgUserData;
@property (nonatomic, retain) UIImage *imgPlayerData;


@property (nonatomic) BOOL FBConnected;
@property (nonatomic) BOOL FBChecked;

@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic, retain) User *user;
@property (nonatomic, retain) User *player;

@property (nonatomic, retain) NSString *correctChoice;
@property (nonatomic, retain) NSMutableArray *mediaType;
@property (nonatomic, retain) NSMutableArray *mediaURLs;
@property (nonatomic, retain) NSMutableArray *mediaLegals;
@property (nonatomic, retain) NSMutableArray *mediaTNs;
@property (nonatomic, retain) NSMutableArray *etailers;
@property (nonatomic, retain) NSMutableArray *mediaNames;
@property (nonatomic, retain) NSMutableArray *questions;
@property (nonatomic, retain) NSMutableArray *choices;

@property (nonatomic, retain) NSMutableArray *media_id_array;
@property (nonatomic, retain) NSMutableArray *choice_var_array;
@property (nonatomic, retain) NSMutableArray *timeSpends;
@property (nonatomic, retain) NSMutableArray *durations;

@property (nonatomic, retain) NSString *challenge_type;
@property (nonatomic, retain) NSMutableArray *gameplay_status;
@property (nonatomic, retain) NSMutableArray *gameplay_round_array;
@property (nonatomic, retain) NSMutableArray *challenge_game_id_array;
@property (nonatomic, retain) NSMutableArray *challenge_id_array;
@property (nonatomic, retain) NSMutableArray *challenge_genre_type_array;
@property (nonatomic, retain) NSMutableArray *challenge_player;

@property (nonatomic, retain) NSMutableArray *history_array;

@property (nonatomic, retain) NSMutableArray *round_user_time_array;
@property (nonatomic, retain) NSMutableArray *round_player_time_array;
@property (nonatomic, retain) NSMutableArray *round_name_array;
@property (nonatomic, retain) NSMutableArray *round_etailer_array;
@property (nonatomic, retain) NSMutableArray *round_thumbnail_array;

@end
