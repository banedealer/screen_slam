//
//  ChoosePlayerType.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/12/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
//#import <FacebookSDK/FacebookSDK.h>
#import "Facebook.h"

@interface ChoosePlayerType : UIViewController {
    AppDelegate *appDelegate;
    
    FBFriendPickerViewController *friendPickerController;
}
@property (nonatomic, retain) AppDelegate *appDelegate;
@property (nonatomic, retain) FBFriendPickerViewController *friendPickerController;

- (IBAction)pickFriendsClick:(UIButton *)sender;
- (IBAction)pickUserClick:(id)sender;

- (IBAction)pickRandomsClick:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIButton *bFacebook;
@property (strong, nonatomic) IBOutlet UIButton *bUser;
@property (strong, nonatomic) IBOutlet UIButton *bRandom;


@end
