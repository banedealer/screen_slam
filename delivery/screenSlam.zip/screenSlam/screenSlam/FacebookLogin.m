//
//  FacebookLogin.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/11/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "FacebookLogin.h"


@interface FacebookLogin ()

@end

@implementation FacebookLogin
@synthesize appDelegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dismissCurrentView:) name:@"reloadGameInfo" object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doFBConnect:(id)sender {
    [appDelegate openSession];
    
}

- (IBAction)skipFBConnect:(id)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    appDelegate.FBChecked = YES;
    
    
    // if the user choose not to connect with fb, then check if this device hv a uid previously
    
    // if this device is registered
    if ([defaults objectForKey:@"uid"] != NULL){
        
        appDelegate.user.id = [defaults objectForKey:@"uid"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGameInfo" object:nil];
        
    // if this device is not register, then create a new user to the system
    }else{
        
        NSLog(@"creating guest");
        // set to guest
        appDelegate.user.id = @"0";
        appDelegate.user.fid = @"0";
        appDelegate.user.fname = @"guest";
        appDelegate.user.lname = @"guest";
        appDelegate.user.thumbnail = [NSString stringWithFormat:@"%@/include/images/avatar.png", appDelegate.BASE_URL];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGameInfo" object:nil];
    }
    
}

-(void)dismissCurrentView:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(dismissCurrentViewInMain) withObject:nil waitUntilDone:YES];
}
-(void)dismissCurrentViewInMain {
     [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
@end
