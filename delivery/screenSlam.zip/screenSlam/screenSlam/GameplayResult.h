//
//  GameplayResult.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/6/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface GameplayResult : UIViewController {
    AppDelegate *appDelegate;
    
}
@property (nonatomic, retain) AppDelegate *appDelegate;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *pbHistory;


- (IBAction)closeResult:(id)sender;

@end
