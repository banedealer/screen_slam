//
//  FacebookLogin.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/11/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface FacebookLogin : UIViewController {
    AppDelegate *appDelegate;
}
@property (nonatomic, retain) AppDelegate *appDelegate;

- (IBAction)doFBConnect:(id)sender;
- (IBAction)skipFBConnect:(id)sender;

@end
