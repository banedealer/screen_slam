//
//  HelpScreen.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/16/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface HelpScreen : UIViewController {
    AppDelegate *appDelegate;
}

@property (nonatomic, retain) AppDelegate *appDelegate;
@property (strong, nonatomic) IBOutlet UIScrollView *helpScroll;

- (IBAction)closeHelpScreen:(id)sender;

@end
