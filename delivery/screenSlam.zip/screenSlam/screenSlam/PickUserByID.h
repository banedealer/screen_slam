//
//  PickUserByID.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/13/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface PickUserByID : UIViewController {
    AppDelegate *appDelegate;
}
- (IBAction)pickUser:(id)sender;
- (IBAction)cancelPickUser:(id)sender;
@property (nonatomic, retain) AppDelegate *appDelegate;
@property (strong, nonatomic) IBOutlet UITextField *txtUID;

@end
