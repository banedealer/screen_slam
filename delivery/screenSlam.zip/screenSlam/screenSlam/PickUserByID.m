//
//  PickUserByID.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/13/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "PickUserByID.h"
#import "MediaSelection.h"
#import "AppDelegate.h"
#import "TBXML+HTTP.h"

@interface PickUserByID ()

@end

@implementation PickUserByID
@synthesize appDelegate;
@synthesize txtUID;

// static function that handle xml parsing
TBXMLFailureBlock checkUIDFailure = ^(TBXML *tbxmlDocument, NSError * error) {
    NSLog(@"Error! %@ %@", [error localizedDescription], [error userInfo]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionError" object:nil];
};

TBXMLSuccessBlock checkUIDSuccess = ^(TBXML *tbxmlDocument) {
    
    
    TBXMLElement *rootElement = tbxmlDocument.rootXMLElement;
    TBXMLElement *valid = [TBXML childElementNamed:@"valid" parentElement:rootElement];
    NSString *validResult= [TBXML textForElement:valid];
    
    NSLog(@"responsee from check uid %@ %@", [TBXML textForElement:valid], validResult);
    
    if ([validResult isEqualToString:@"2"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"existAlert" object:nil];
    }else if ([validResult isEqualToString:@"1"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"validAction" object:nil];
        
    }else{
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"invalidAlert" object:nil];
    }
    
};

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [txtUID resignFirstResponder];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)handlePan:(UIPanGestureRecognizer*)recognizer {
    
    CGPoint translation = [recognizer translationInView:recognizer.view];
    if (translation.x > 2) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // pan gesture
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [panGesture setMaximumNumberOfTouches:1];
    [self.view addGestureRecognizer:panGesture];
    
    appDelegate = [[UIApplication sharedApplication] delegate];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(existAlert:) name:@"existAlert" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(invalidAlert:) name:@"invalidAlert" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(validAction:) name:@"validAction" object:nil];
    
   
}


-(void)existAlert:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(existAlertInMain) withObject:nil waitUntilDone:YES];
}
-(void)validAction:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(validActionInMain) withObject:nil waitUntilDone:YES];
}
-(void)validActionInMain{
    self.view.userInteractionEnabled = YES;
    MediaSelection *mediaSelection = [[MediaSelection alloc] initWithNibName:@"MediaSelection" bundle:nil];
    [self.navigationController pushViewController:mediaSelection animated:YES];
}

-(void)invalidAlert:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(invalidAlertInMain) withObject:nil waitUntilDone:YES];
}
-(void)existAlertInMain {
    appDelegate.uid_challenge_target = nil;
    self.view.userInteractionEnabled = YES;
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Oops!"
                              message:@"Sorry! You are already playing with that player."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
    [alertView show];
}


-(void)invalidAlertInMain {
    appDelegate.uid_challenge_target = nil;
    self.view.userInteractionEnabled = YES;
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Oops!"
                              message:@"Sorry, that User ID doesn't exist."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
    [alertView show];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)pickUser:(id)sender {
    // check if the input field is empty
    if ([txtUID.text isEqualToString:@""] || [txtUID.text intValue] == [appDelegate.user.id integerValue]){
        
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Oops!"
                                  message:@"Sorry, that User ID doesn't exist."
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
        
    }else{
        
        self.view.userInteractionEnabled = NO;
        // load game info from server
        appDelegate.uid_challenge_target = txtUID.text;
        NSString *urlString = [NSString stringWithFormat:@"%@/service/checkUID.php?user_id=%@&player_id=%@&fb=0", appDelegate.BASE_URL, appDelegate.user.id, txtUID.text];
        NSLog(@"url:%@",urlString);
        TBXML *xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:urlString] success:checkUIDSuccess failure:checkUIDFailure];
        xmlData = nil;
        
    }
    
}

- (IBAction)cancelPickUser:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
