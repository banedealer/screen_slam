//
//  TotalScore.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/3/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "TotalScore.h"
#import "GrandScoreBoard.h"

@interface TotalScore ()

@end

@implementation TotalScore
@synthesize appDelegate;
@synthesize txtScore;
@synthesize txtResult,txtRound;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    // display total score
    int i = 0;
    double totalScore = 0;
    while (i < [appDelegate.timeSpends count]){
        
        double timeSpend = [appDelegate.timeSpends[i] doubleValue];
        double duration = [appDelegate.durations[i] doubleValue];
        if (timeSpend != -1){
            totalScore += (timeSpend == 0 ? 1000 : ceil((duration - timeSpend)/duration*900+100));
        }
        i++;
    }
    [txtScore setText:[NSString stringWithFormat:@"%g", totalScore]];
    appDelegate.user.score += totalScore;
    
    // check winner if user is playing the challenge
    if ([appDelegate.challenge_type isEqualToString:@"challenge"]){
        if (totalScore > appDelegate.player.game_score){
            appDelegate.player.opponent_won++;
        }else if (totalScore < appDelegate.player.game_score){
            appDelegate.player.won++;
        }
    }
    
    // display result of two player
    [txtResult setText:[NSString stringWithFormat:@"%d:%d", appDelegate.player.opponent_won, appDelegate.player.won]];    
    
    // display the current round number
    [txtRound setText:[NSString stringWithFormat:@"ROUND %d", appDelegate.gameplay_round]];
    
    if (appDelegate.player.opponent_won == 5 || appDelegate.player.won == 5){
        [self performSelector:@selector(gotoGrandScoreBoard) withObject:nil afterDelay:4];
    }else{
        [self gotoGrandScoreBoard];
    }
    
}

-(void) gotoGrandScoreBoard{
    GrandScoreBoard *grandScoreBoard = [[GrandScoreBoard alloc] initWithNibName:@"GrandScoreBoard" bundle:nil];
    [self.navigationController pushViewController:grandScoreBoard animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
