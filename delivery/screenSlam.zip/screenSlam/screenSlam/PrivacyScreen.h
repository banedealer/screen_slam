//
//  PrivacyScreen.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/16/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrivacyScreen : UIViewController
- (IBAction)closePrivacyScreen:(id)sender;
@property (strong, nonatomic) IBOutlet UIScrollView *privacyScroll;

@end
