//
//  GenreStarter.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "GenreStarter.h"
#import "TBXML+HTTP.h"
#import "MediaMainPanel.h"

@interface GenreStarter ()

@end

@implementation GenreStarter
@synthesize appDelegate;
@synthesize pLoader,txtPoint;
@synthesize xmlReady;
@synthesize connect,tempData,request;
@synthesize imgGenre,imgPlayer,imgUser;
@synthesize txtPlayer,txtPlayerScore,txtUser,txtUserScore;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

// static function that handle xml parsing
TBXMLFailureBlock failureBlock = ^(TBXML *tbxmlDocument, NSError * error) {
    NSLog(@"Error! %@ %@", [error localizedDescription], [error userInfo]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionError" object:nil];
};

TBXMLSuccessBlock successBlock = ^(TBXML *tbxmlDocument) {
    NSLog(@"start xml load");
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.player = [[User alloc] init];
    
    TBXMLElement *rootElement = tbxmlDocument.rootXMLElement;
    
    // parse opponent data
    TBXMLElement *player = [TBXML childElementNamed:@"player" parentElement:rootElement];    
    TBXMLElement *player_id = [TBXML childElementNamed:@"player_user_id" parentElement:player];
    appDelegate.player.id = [TBXML textForElement:player_id];
    TBXMLElement *player_fid = [TBXML childElementNamed:@"player_user_fid" parentElement:player];
    appDelegate.player.fid = [TBXML textForElement:player_fid];
    TBXMLElement *player_fname = [TBXML childElementNamed:@"player_user_fname" parentElement:player];
    appDelegate.player.fname = [TBXML textForElement:player_fname];
    TBXMLElement *player_lname = [TBXML childElementNamed:@"player_user_lname" parentElement:player];
    appDelegate.player.lname = [TBXML textForElement:player_lname];
    TBXMLElement *player_thumbnail = [TBXML childElementNamed:@"player_user_thumbnail" parentElement:player];
    appDelegate.player.thumbnail = [TBXML textForElement:player_thumbnail];
    TBXMLElement *player_score = [TBXML childElementNamed:@"player_user_score" parentElement:player];
    appDelegate.player.score = [[TBXML textForElement:player_score] integerValue];
    
    // parse opponent time spent record
    if ([appDelegate.challenge_type isEqualToString:@"challenge"]){
        TBXMLElement *player_game_score = [TBXML childElementNamed:@"player_game_score" parentElement:player];
        appDelegate.player.game_score = [[TBXML textForElement:player_game_score] integerValue];
        
        TBXMLElement *timeSpends = [TBXML childElementNamed:@"timeSpends" parentElement:player];
        TBXMLElement *elapsed = [TBXML childElementNamed:@"elapsed" parentElement:timeSpends];
        appDelegate.player.timeSpends = [[NSMutableArray alloc] init];
        while (elapsed != nil){
            [appDelegate.player.timeSpends addObject:[TBXML textForElement:elapsed]];
            elapsed = [TBXML nextSiblingNamed:@"elapsed" searchFromElement:elapsed];
        }
    }
    
    // if this is a new game, then set both score to 0
    if (appDelegate.game_id == 0){
        appDelegate.player.won = 0;
        appDelegate.player.opponent_won = 0;
    }else{
        User *player = appDelegate.challenge_player[appDelegate.challengePointer];
        appDelegate.player.won = player.won;
        appDelegate.player.opponent_won = player.opponent_won;
    }

    
    // parse media data
    TBXMLElement *mediasElement = [TBXML childElementNamed:@"media" parentElement:rootElement];
    while (mediasElement != nil){
        TBXMLElement *media_type = [TBXML childElementNamed:@"media_type" parentElement:mediasElement];
        [appDelegate.mediaType addObject:[TBXML textForElement:media_type]];
        TBXMLElement *media_url = [TBXML childElementNamed:@"media_url" parentElement:mediasElement];
        [appDelegate.mediaURLs addObject:[TBXML textForElement:media_url]];
        
        TBXMLElement *media_thumbnail = [TBXML childElementNamed:@"media_thumbnail" parentElement:mediasElement];
        [appDelegate.mediaTNs addObject:[TBXML textForElement:media_thumbnail]];
        TBXMLElement *media_etailer = [TBXML childElementNamed:@"media_etailer" parentElement:mediasElement];
        [appDelegate.etailers addObject:[TBXML textForElement:media_etailer]];
        
        TBXMLElement *media_name = [TBXML childElementNamed:@"media_name" parentElement:mediasElement];
        NSString *tempString = [[TBXML textForElement:media_name] stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
        tempString = [tempString stringByReplacingOccurrencesOfString:@"&#x92;" withString:@"'"];
        [appDelegate.mediaNames addObject:tempString];
        
        //VVadded legal
        TBXMLElement *media_legal = [TBXML childElementNamed:@"media_legal" parentElement:mediasElement];
        [appDelegate.mediaLegals addObject:[TBXML textForElement:media_legal]];
        
        TBXMLElement *question_value = [TBXML childElementNamed:@"question_value" parentElement:mediasElement];
        [appDelegate.questions addObject:[TBXML textForElement:question_value]];
        
        TBXMLElement *media_id = [TBXML childElementNamed:@"media_id" parentElement:mediasElement];
        [appDelegate.media_id_array addObject:[TBXML textForElement:media_id]];
        TBXMLElement *choice_var = [TBXML childElementNamed:@"choice_var" parentElement:mediasElement];
        [appDelegate.choice_var_array addObject:[TBXML textForElement:choice_var]];
        
        // choice
        NSMutableArray *choiceArray = [[NSMutableArray alloc] init];
        TBXMLElement *choicesElement = [TBXML childElementNamed:@"choice" parentElement:mediasElement];
        TBXMLElement *choicesValueElement = [TBXML childElementNamed:@"choice_value" parentElement:choicesElement];
        while (choicesValueElement != nil){
            
            NSString *tempString = [[TBXML textForElement:choicesValueElement] stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
            tempString = [tempString stringByReplacingOccurrencesOfString:@"&#x92;" withString:@"'"];
            [choiceArray addObject:tempString];

            choicesValueElement = [TBXML nextSiblingNamed:@"choice_value" searchFromElement:choicesValueElement];
        }
        [appDelegate.choices addObject:choiceArray];
        
        mediasElement = [TBXML nextSiblingNamed:@"media" searchFromElement:mediasElement];
    }
    NSLog(@"finish xml load");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"xmlLoaded" object:nil];
    
    
};

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
    NSLog(@"connection error");
}

- (void)connection: (NSURLConnection *)connection didReceiveResponse:
(NSURLResponse *)aResponse
{
    NSLog(@"connection establish");
}

-(void) connection:(NSURLConnection *)connection didReceiveData:
(NSData *) incomingData
{
    [tempData appendData:incomingData];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSArray *pathList = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [pathList objectAtIndex:0];
    
    
    path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"playerIMG"]];
    
    
    [tempData writeToFile:path atomically:NO];
    tempData = nil;
    
    appDelegate.imgPlayerData = [UIImage imageWithContentsOfFile:path];    
    
    
    [self performSelectorOnMainThread:@selector(setAvator) withObject:nil waitUntilDone:NO];
    if (xmlReady){
        //bStart.hidden = NO;
        [self performSelectorOnMainThread:@selector(setSkipTimer) withObject:nil waitUntilDone:YES];
    }else{
        xmlReady = YES;
    }
    
}

-(void) setAvator {
    [imgPlayer setImage:appDelegate.imgPlayerData];
    txtPoint.hidden = NO;
    pLoader.hidden = YES;
}

-(void) setSkipTimer {
    
    [self performSelector:@selector(gotoMedia) withObject:nil afterDelay:2];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // init environment
    txtPoint.hidden = YES;
    xmlReady = NO;
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"iphone_bg.jpg"]];
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    // load the genre background first if it is the promo
    if ([appDelegate.genre isEqualToString:@"promo"]){
        NSData *promoData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/include/images/genre_promo.png", appDelegate.BASE_URL]]];
        [imgGenre setImage:[UIImage imageWithData:promoData]];
    }else{
        [imgGenre setImage:[UIImage imageNamed:[NSString stringWithFormat:@"genre_%@.png", appDelegate.genre]]];
    }
    
    
    // load media by genre
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startMediaByGenre:) name:@"xmlLoaded" object:nil];
    [self loadXML];
    // set display
    [txtUser setText:[NSString stringWithFormat:@"%@ %@.", appDelegate.user.fname, [appDelegate.user.lname substringToIndex:1]]];
    if ([appDelegate.user.fid isEqualToString:@"0"]){
        [txtUser setText:[NSString stringWithFormat:@"%@", appDelegate.user.fname]];
    }
    [imgUser setImage:appDelegate.imgUserData];
    [txtUserScore setText:[NSString stringWithFormat:@"%d", appDelegate.user.score]];
    
    
    if ([appDelegate.challenge_type isEqualToString:@"challenge"]){
        // load user detail
        User *player = appDelegate.challenge_player[appDelegate.challengePointer];
        
        // request remote profile img
        request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:player.thumbnail]];
        [request setHTTPMethod:@"GET"];
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"Mobile Safari 1.1.3 (iPhone; U; CPU like Mac OS X; en)" forHTTPHeaderField:@"User-Agent"];
        tempData = [NSMutableData alloc];
        connect = [[NSURLConnection alloc] initWithRequest:request delegate:self];
        
        [txtPlayer setText:[NSString stringWithFormat:@"%@ %@.", player.fname, [player.lname  substringToIndex:1]]];
        if ([player.fid isEqualToString:@"0"]){
            [txtPlayer setText:[NSString stringWithFormat:@"%@", player.fname]];
        }
        /*NSData *imgPlayerData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:appDelegate.challenge_player_user_thumbnail_array[appDelegate.challengePointer]]];
        [imgPlayer setImage:[UIImage imageWithData:imgPlayerData]];*/
        [txtPlayerScore setText:[NSString stringWithFormat:@"%d", player.score]];
    }
    
}

-(void)loadXML{
    
    // init/reset the all the memory
    appDelegate.videoPointer = 0;
    appDelegate.mediaType = [[NSMutableArray alloc] init];
    appDelegate.mediaURLs = [[NSMutableArray alloc] init];
    appDelegate.mediaLegals = [[NSMutableArray alloc] init];
    appDelegate.mediaTNs = [[NSMutableArray alloc] init];
    appDelegate.etailers = [[NSMutableArray alloc] init];
    appDelegate.mediaNames = [[NSMutableArray alloc] init];
    appDelegate.questions = [[NSMutableArray alloc] init];
    appDelegate.choices = [[NSMutableArray alloc] init];
    
    appDelegate.media_id_array = [[NSMutableArray alloc] init];
    appDelegate.choice_var_array = [[NSMutableArray alloc] init];
    appDelegate.timeSpends = [[NSMutableArray alloc] init];
    appDelegate.durations = [[NSMutableArray alloc] init];
    
    
    TBXML *xmlData;
    if ([appDelegate.challenge_type isEqualToString:@"self"]){
        // if no fb user is not set, then do random
        
        if (appDelegate.fb_challenge_target != nil){
            xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/getMedia.php?by=fb&type=%@&user_id=%d&target=%@&target_fname=%@&target_lname=%@", appDelegate.BASE_URL, appDelegate.genre, [appDelegate.user.id integerValue], appDelegate.fb_challenge_target, appDelegate.fb_challenge_target_fname, appDelegate.fb_challenge_target_lname]] success:successBlock failure:failureBlock];
        }else if(appDelegate.uid_challenge_target != nil){
            xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/getMedia.php?by=uid&type=%@&user_id=%d&target=%@", appDelegate.BASE_URL, appDelegate.genre, [appDelegate.user.id integerValue], appDelegate.uid_challenge_target]] success:successBlock failure:failureBlock];
            NSLog(@"%@/service/getMedia.php?by=uid&type=%@&user_id=%d&target=%@", appDelegate.BASE_URL, appDelegate.genre, [appDelegate.user.id integerValue], appDelegate.uid_challenge_target);
        }else{
            xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/getMedia.php?type=%@&user_id=%d", appDelegate.BASE_URL, appDelegate.genre, [appDelegate.user.id integerValue]]] success:successBlock failure:failureBlock];
        }            
    }else if ([appDelegate.challenge_type isEqualToString:@"challenge"]){
        xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/getChallenge.php?challenge_id=%@", appDelegate.BASE_URL, appDelegate.challenge_id_array[appDelegate.challengePointer]]] success:successBlock failure:failureBlock];
        NSLog(@"%@",[NSString stringWithFormat:@"%@/service/getChallenge.php?challenge_id=%@", appDelegate.BASE_URL, appDelegate.challenge_id_array[appDelegate.challengePointer]]);
    }
    xmlData = nil;
    
}

-(void)startMediaByGenre:(NSNotification *)notice{
    
    [self performSelectorOnMainThread:@selector(showStartButton) withObject:nil waitUntilDone:YES];
}

-(void)showStartButton {
    
    
    if ([appDelegate.challenge_type isEqualToString:@"self"]){
        xmlReady = YES;
        
        // load opponent
        request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:appDelegate.player.thumbnail]];
        [request setHTTPMethod:@"GET"];
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"Mobile Safari 1.1.3 (iPhone; U; CPU like Mac OS X; en)" forHTTPHeaderField:@"User-Agent"];
        tempData = [NSMutableData alloc];
        connect = [[NSURLConnection alloc] initWithRequest:request delegate:self];    
        
        [txtPlayer setText:[NSString stringWithFormat:@"%@ %@.", appDelegate.player.fname, [appDelegate.player.lname substringToIndex:1]]];
        if ([appDelegate.player.fid isEqualToString:@"0"]){
            [txtPlayer setText:[NSString stringWithFormat:@"%@", appDelegate.player.fname]];
        }
        /*NSData *imgPlayerData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:appDelegate.player_thumbnail]];
        [imgPlayer setImage:[UIImage imageWithData:imgPlayerData]];*/
        [txtPlayerScore setText:[NSString stringWithFormat:@"%d",appDelegate.player.score]];
        
        
        
        
    }else{
        if (xmlReady){
            //bStart.hidden = NO;
            [self performSelectorOnMainThread:@selector(setSkipTimer) withObject:nil waitUntilDone:YES];
        }else{
            xmlReady = YES;
        }
    }
    
    //bStart.hidden = NO;
    
}
- (void) gotoMedia {
    MediaMainPanel *mediaMainPanel = [[MediaMainPanel alloc] initWithNibName:@"MediaMainPanel" bundle:nil];
    [self.navigationController pushViewController:mediaMainPanel animated:YES];
}
- (IBAction)gotoMediaMainPanel:(id)sender {
    [self gotoMedia];    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
