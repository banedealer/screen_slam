//
//  AppDelegate.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "AppDelegate.h"
//#import <FacebookSDK/FacebookSDK.h>

#import "ViewController.h"
#import "FacebookLogin.h"

@implementation AppDelegate
@synthesize BASE_URL;
@synthesize isHD;
@synthesize deviceToken;
@synthesize facebook, FBChecked,FBConnected;
@synthesize videoPointer, mediaNames, game_id, gameplay_round;
@synthesize promo_name;
@synthesize genre, challengePointer, fb_challenge_target,uid_challenge_target,fb_challenge_target_fname,fb_challenge_target_lname;
@synthesize imgUserData,imgPlayerData;
@synthesize user;
//@synthesize user_id,user_fid,user_fname,user_lname,user_score,user_thumbnail;
@synthesize player;
//@synthesize player_fid,player_fname,player_id,player_lname,player_score,player_thumbnail,player_timeSpends, player_game_score;
@synthesize correctChoice, mediaType, mediaTNs, mediaURLs, mediaLegals, etailers, questions, choices;
@synthesize durations, timeSpends, media_id_array, choice_var_array;
@synthesize challenge_type, gameplay_status, gameplay_round_array, challenge_game_id_array, challenge_genre_type_array,challenge_id_array,challenge_player;
//@synthesize challenge_type, challenge_genre_type_array,challenge_id_array,challenge_player_user_fid_array,challenge_player_user_fname_array,challenge_player_user_id_array,challenge_player_user_lname_array,challenge_player_user_score_array,challenge_player_user_thumbnail_array;
@synthesize history_array;
@synthesize round_etailer_array,round_name_array,round_player_time_array,round_user_time_array;

// open facebook session
- (void)openSession
{
    [FBSession openActiveSessionWithReadPermissions:nil
                                       allowLoginUI:YES
                                  completionHandler:
     ^(FBSession *session,
       FBSessionState state, NSError *error) {
         [self sessionStateChanged:session state:state error:error];
     }];
}

// detect facebook status changes
- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    NSLog(@"session changed");
    
    
    switch (state) {
        case FBSessionStateOpen: {
            
            // create newuser account if necessary
            [[FBRequest requestForMe] startWithCompletionHandler:
             ^(FBRequestConnection *connection,
               NSDictionary<FBGraphUser> *fb_user,
               NSError *error) {
                 if (!error) {
                     
                     facebook = [[Facebook alloc] initWithAppId:FBSession.activeSession.appID andDelegate:nil];
                     FBChecked = YES;
                     FBConnected = YES;
                     
                     user.id = @"0";
                     user.fid = fb_user.id;
                     user.fname = fb_user.first_name;
                     user.lname = fb_user.last_name;
                     user.thumbnail = [NSString stringWithFormat:@"http://graph.facebook.com/%@/picture?type=large",fb_user.id];
                     [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGameInfo" object:nil];
                     
                 }else{
                     
                     FBChecked = NO;
                     FBConnected = NO;
                 }
             }];
        }
            [FBSession setActiveSession:session];
            break;
        case FBSessionStateClosed:
        case FBSessionStateClosedLoginFailed:
            
            [FBSession.activeSession closeAndClearTokenInformation];
            FBChecked = NO;
            FBConnected = NO;
            [[NSNotificationCenter defaultCenter] postNotificationName:@"displayFBScreen" object:nil];
            
            NSLog(@"login failed, session no longer valid");
            /*[self showLoginView];*/
            break;
        default:
            break;
    }
    /*
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Error"
                                  message:error.localizedDescription
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }*/
}



// handle callback
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    return [FBSession.activeSession handleOpenURL:url];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // init the viewcontroller
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];    
    self.viewController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
    
    
    // init the selected view
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    [UIApplication sharedApplication].statusBarHidden = YES;
    
    // init base url default value
    BASE_URL = @"http://screenslam.foxfilm.com";
    
    // This file URL is hard-coded, its contents point to the header for everything else
    NSURL *url = [[NSURL alloc] initWithString:@"http://screenslam.foxfilm.com/configURLHead.txt"];
    NSError *error = nil;
    NSStringEncoding encoding;
    NSString *myString = [[NSString alloc] initWithContentsOfURL:url
                                                    usedEncoding:&encoding
                                                           error:&error];
    if ([myString length] != 0) {
        BASE_URL = [NSString stringWithString:myString];
    }
    
    // Let the device know we want to receive push notifications
    deviceToken = nil;
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    ///////////////////////////////////////////////////
    //test the notification locally
    
    /*
     UILocalNotification *notification=[[UILocalNotification alloc] init];
     if (notification!=nil) {
     NSLog(@">> support local notification");
     NSDate *now=[NSDate new];
     notification.fireDate=[now addTimeInterval:10];
     notification.timeZone=[NSTimeZone defaultTimeZone];
     notification.alertBody=@"Test MSG test";
     [[UIApplication sharedApplication]   scheduleLocalNotification:notification];
     }
    */ 
    /////////////////////////////////////////////
    
    return YES;
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    
    NSLog(@"remote push info:%@", userInfo);
    for (id key in userInfo) {
        NSLog(@"key: %@, value: %@", key, [userInfo objectForKey:key]);
        
    }
}

//receive the notifications
///////////////////////////////////////////////////////////////////////
- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)token
{
    
    deviceToken = [token description];
    deviceToken = [deviceToken stringByReplacingOccurrencesOfString :@" " withString:@""];
    deviceToken = [deviceToken stringByReplacingOccurrencesOfString :@"<" withString:@""];
    deviceToken = [deviceToken stringByReplacingOccurrencesOfString :@">" withString:@""];
    NSLog(@"final token is %@", deviceToken);
    
    
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
	NSLog(@"Failed to get token, error: %@", error);
}
/////////////////////////////////////////////////////////////////////////




- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [FBSession.activeSession close];
}

@end
