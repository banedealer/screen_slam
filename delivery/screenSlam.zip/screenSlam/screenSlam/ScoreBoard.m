//
//  ScoreBoard.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "ScoreBoard.h"
#import "MediaMainPanel.h"
#import "TotalScore.h"

@interface ScoreBoard ()

@end

@implementation ScoreBoard
@synthesize appDelegate;
@synthesize txtScore,txtTime, txtCorrectChoice;
@synthesize imgResult;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    // init environment
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"iphone_bg.jpg"]];
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    // display score
    double timeSpent = [appDelegate.timeSpends[appDelegate.videoPointer] doubleValue];
    NSLog(@"result %.0f - %.0f", [appDelegate.durations[appDelegate.videoPointer] doubleValue], timeSpent);
    
    // for wrong ans
    if (timeSpent == -1 ){
        //[txtScore setText:@"WRONG!"];
        [txtCorrectChoice setText:[NSString stringWithFormat:@"%@",appDelegate.correctChoice]];
        [imgResult setImage:[UIImage imageNamed:@"iphone_bg_wrong_answer.jpg"]];
        [txtScore setText:@""];
        [txtTime setText:@""];
    // for correct ans
    }else{
        [imgResult setImage:[UIImage imageNamed:@"iphone_bg_correct_answer.jpg"]];
        // preset it to full mark
        double score = 1000;
        
        if (timeSpent != 0){
            score = ceil(([appDelegate.durations[appDelegate.videoPointer] doubleValue] - timeSpent)/[appDelegate.durations[appDelegate.videoPointer] doubleValue]*900+100);
        }
        [txtScore setText:[NSString stringWithFormat:@"%.0f", score]];
        [txtTime setText:[NSString stringWithFormat:@"%.2f s", timeSpent]];
    }
    
    // goto next media after 2 second
    [self performSelector:@selector(nextMedia) withObject:nil afterDelay:2];
}

-(void) nextMedia {
    if (appDelegate.videoPointer < [appDelegate.mediaURLs count] - 1){
        appDelegate.videoPointer++;
        MediaMainPanel *mediaMainPanel = [[MediaMainPanel alloc] initWithNibName:@"MediaMainPanel" bundle:nil];
        [self.navigationController pushViewController:mediaMainPanel animated:YES];
    }else{
        TotalScore *totalScore = [[TotalScore alloc] initWithNibName:@"TotalScore" bundle:nil];
        [self.navigationController pushViewController:totalScore animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
