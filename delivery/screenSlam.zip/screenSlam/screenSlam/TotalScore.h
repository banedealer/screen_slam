//
//  TotalScore.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 12/3/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface TotalScore : UIViewController {
    AppDelegate *appDelegate;
}

@property (nonatomic, retain) AppDelegate *appDelegate;

@property (strong, nonatomic) IBOutlet UILabel *txtScore;
@property (strong, nonatomic) IBOutlet UILabel *txtResult;
@property (strong, nonatomic) IBOutlet UILabel *txtRound;

@end
