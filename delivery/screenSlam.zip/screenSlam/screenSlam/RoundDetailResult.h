//
//  RoundDetailResult.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/8/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface RoundDetailResult : UIViewController {
    AppDelegate *appDelegate;
}

@property (strong, nonatomic) IBOutlet UIScrollView *mediaScroll;
@property (nonatomic, retain) AppDelegate *appDelegate;
- (IBAction)closeResult:(id)sender;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *pbRound;


@end
