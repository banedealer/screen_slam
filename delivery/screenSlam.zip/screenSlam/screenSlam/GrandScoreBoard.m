//
//  GrandScoreBoard.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/30/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "GrandScoreBoard.h"
#import "TBXML+HTTP.h"
#import "Facebook.h"
#import "AppDelegate.h"

@interface GrandScoreBoard ()

@end

@implementation GrandScoreBoard
@synthesize appDelegate;
@synthesize endGame;
@synthesize bDone, bNewGame, bPlay;
@synthesize mediaScroll;
@synthesize imgPlayer,imgUser;
@synthesize txtPlayer,txtPlayerScore,txtPlayerGameScore, txtUser,txtUserScore, txtUserGameScore,txtUserWon,txtPlayerWon,txtRound;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

// static function that handle xml parsing
TBXMLFailureBlock saveChallengeFailure = ^(TBXML *tbxmlDocument, NSError * error) {
    NSLog(@"Error! %@ %@", [error localizedDescription], [error userInfo]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionError" object:nil];
};

TBXMLSuccessBlock saveChallengeSuccess = ^(TBXML *tbxmlDocument) {
    
    
    
};

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // init environment
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showControl:) name:@"reloadGameInfo" object:nil];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"iphone_bg.jpg"]];
    appDelegate = [[UIApplication sharedApplication] delegate];
    bDone.enabled = NO;
    bPlay.enabled = NO;
    endGame = @"false";
    // check if the target is facebook user then send app request
    /*if (appDelegate.fb_challenge_target != nil && [appDelegate.challenge_type isEqualToString:@"self"]){
        NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Screen Slam", @"title", @"Someone invite you to play screen slam.", @"message", appDelegate.fb_challenge_target, @"to", nil];
        [appDelegate.facebook dialog:@"apprequests" andParams:params andDelegate:nil];
    }*/
    // check it is the last round
    if ([appDelegate.challenge_type isEqualToString:@"challenge"] && (appDelegate.player.opponent_won == 5 || appDelegate.player.won == 5)){
        endGame = @"true";
    }   
    
    // display user game score
    NSInteger winner_id = 0;
    int i = 0;
    double userScore = 0;
    while (i < [appDelegate.durations count]){
        double userTimeSpend = [appDelegate.timeSpends[i] doubleValue];
        double duration = [appDelegate.durations[i] doubleValue];
        NSLog(@"playtimer %g   %g",userTimeSpend, duration);
        if (userTimeSpend != -1){
            userScore += (userTimeSpend == 0 ? 1000 : ceil((duration - userTimeSpend)/duration*900+100));
        }        
        i++;
    }
    [txtUserGameScore setText:[NSString stringWithFormat:@"%g", userScore]];
    // display player game score
    if ([appDelegate.challenge_type isEqualToString:@"challenge"]){
        
        [txtPlayerGameScore setText:[NSString stringWithFormat:@"%d", appDelegate.player.game_score]];
        
        
        if (userScore > appDelegate.player.game_score){
            winner_id = [appDelegate.user.id integerValue];
        }else if (userScore < appDelegate.player.game_score){
            winner_id = [appDelegate.player.id integerValue];
        }else{
            winner_id = [appDelegate.user.id integerValue];
        }
    }else{
        [txtPlayerGameScore setText:[NSString stringWithFormat:@"?"]];
    }
    // display title
    [txtUser setText:[NSString stringWithFormat:@"%@ %@.", appDelegate.user.fname, [appDelegate.user.lname substringToIndex:1]]];
    if ([appDelegate.user.fid isEqualToString:@"0"]){
        [txtUser setText:[NSString stringWithFormat:@"%@", appDelegate.user.fname]];
    }
    [imgUser setImage:appDelegate.imgUserData];
    [txtUserScore setText:[NSString stringWithFormat:@"%d", appDelegate.user.score]];
    
    [imgPlayer setImage:appDelegate.imgPlayerData];
    [txtPlayer setText:[NSString stringWithFormat:@"%@ %@.", appDelegate.player.fname, [appDelegate.player.lname substringToIndex:1]]];
    if ([appDelegate.player.fid isEqualToString:@"0"]){
        [txtPlayer setText:[NSString stringWithFormat:@"%@", appDelegate.player.fname]];
    }
    [txtPlayerScore setText:[NSString stringWithFormat:@"%d",appDelegate.player.score]];
    
    // display won rounds of two player
    [txtUserWon setText:[NSString stringWithFormat:@"%d", appDelegate.player.opponent_won]];
    [txtPlayerWon setText:[NSString stringWithFormat:@"%d", appDelegate.player.won]];
    
    // display the current round number
    [txtRound setText:[NSString stringWithFormat:@"%d", appDelegate.gameplay_round]];    
    
    // display detail results
    double height = 60+8;
    double starty = 3;
    [mediaScroll flashScrollIndicators];
    [mediaScroll setScrollEnabled:YES];
    [mediaScroll setContentSize:CGSizeMake(260, 5*height)];
    int j = 0;
    
    while (j < [appDelegate.mediaNames count]) {
        // image panel
        //UIImageView *imgPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"panel_challenge_results_yellow.png"]];
        UIImageView *imgPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"panel_challengeboard_yellow.png"]];
        imgPanel.frame = CGRectMake(8, starty+j*height, 266, 60);
        [mediaScroll addSubview:imgPanel];
        
        // media thumbnail panel
        UIImageView *mediaPanel;
        if ([appDelegate.mediaTNs[j] isEqualToString:@"default"]){
            mediaPanel = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"default_fox_title.png"]];
        }else{
            NSData *mediaTNData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@", appDelegate.BASE_URL, appDelegate.mediaTNs[j]]]];
            mediaPanel = [[UIImageView alloc] initWithImage:[UIImage imageWithData:mediaTNData]];
        }        
        mediaPanel.frame = CGRectMake(8+15, starty+j*height+5, 50, 50);
        [mediaScroll addSubview:mediaPanel];
        
        // user display
        UIImageView *imgUserPanel = [[UIImageView alloc] initWithImage:appDelegate.imgUserData];
        imgUserPanel.frame = CGRectMake(175, starty+j*height+5, 40, 40);
        imgUserPanel.contentMode = UIViewContentModeScaleAspectFill;
        imgUserPanel.clipsToBounds = YES;
        [mediaScroll addSubview:imgUserPanel];
        
        // user  border
        UIImageView *imgUserBorder = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"profileBorder.png"]];
        imgUserBorder.frame = CGRectMake(174, starty+j*height+4, 42, 42);
        imgUserBorder.contentMode = UIViewContentModeScaleAspectFill;
        imgUserBorder.clipsToBounds = YES;
        [mediaScroll addSubview:imgUserBorder];
        
        // player display
        UIImageView *imgPlayerPanel = [[UIImageView alloc] initWithImage:appDelegate.imgPlayerData];
        imgPlayerPanel.frame = CGRectMake(225, starty+j*height+5, 40, 40);
        imgPlayerPanel.contentMode = UIViewContentModeScaleAspectFill;
        imgPlayerPanel.clipsToBounds = YES;
        [mediaScroll addSubview:imgPlayerPanel];
        
        // player border
        UIImageView *imgPlayerBorder = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"profileBorder.png"]];
        imgPlayerBorder.frame = CGRectMake(224, starty+j*height+4, 42, 42);
        imgPlayerBorder.contentMode = UIViewContentModeScaleAspectFill;
        imgPlayerBorder.clipsToBounds = YES;
        [mediaScroll addSubview:imgPlayerBorder];
        
        
        // BUY NOW button
        UIButton *m = [UIButton buttonWithType:UIButtonTypeCustom];
        m.tag = j;
        [m setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateNormal];
        [m setTitleColor:[UIColor colorWithRed:255.f green:255.f blue:255.f alpha:255.f] forState:UIControlStateDisabled];
        /*[m setBackgroundImage:[UIImage imageNamed:@"button_med_f1.png"] forState:UIControlStateNormal];
        [m setBackgroundImage:[UIImage imageNamed:@"button_med_f1.png"] forState:UIControlStateDisabled];*/
        m.backgroundColor = [UIColor clearColor];
        [m addTarget:self action:@selector(gotoURL:) forControlEvents:UIControlEventTouchUpInside];
        m.frame = CGRectMake(71, starty+j*height+30, 75, 22);
        [m setTitle:@"BUY NOW" forState:UIControlStateNormal];
        [m.titleLabel setFont:[UIFont boldSystemFontOfSize:12]];
        [mediaScroll addSubview:m];
        if ([appDelegate.etailers[j] isEqualToString:@"none"]){
            m.enabled = NO;
            m.alpha = 0.6;
        }        
        
        // MEDIA NAME LABEL
        UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(80, starty+j*height+6, 90, 30)];
        l.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        l.backgroundColor = [UIColor clearColor];
        [l setLineBreakMode:NSLineBreakByWordWrapping];
        l.numberOfLines = 2;
        [l setText:appDelegate.mediaNames[j]];
        [l setFont:[UIFont boldSystemFontOfSize:10]];
        [mediaScroll addSubview:l];
        
        // YOUR SCORE label
        UILabel *lbUserScore = [[UILabel alloc] initWithFrame:CGRectMake(170, starty+j*height+37, 50, 30)];
        lbUserScore.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
        lbUserScore.textAlignment = NSTextAlignmentCenter;
        lbUserScore.backgroundColor = [UIColor clearColor];
        if ([appDelegate.timeSpends[j] doubleValue] == -1){
            [lbUserScore setFont:[UIFont boldSystemFontOfSize:7]];
            lbUserScore.textColor = [UIColor colorWithRed:162/255.f green:19/255.f blue:19/255.f alpha:255/255.f];
            [lbUserScore setText:[NSString stringWithFormat:@"WRONG"]];
            [imgUserPanel setAlpha:0.5];
            imgUserBorder.hidden = YES;
        }else{
            [lbUserScore setFont:[UIFont boldSystemFontOfSize:7]];
            [lbUserScore setText:[NSString stringWithFormat:@"%.2fs",[appDelegate.timeSpends[j] doubleValue]]];
            
        }        
        
        [mediaScroll addSubview:lbUserScore];
        
        // PLAYER SCORE LABEL
        if ([appDelegate.challenge_type isEqualToString:@"challenge"]){
            // player score label
            UILabel *lbPlayerScore = [[UILabel alloc] initWithFrame:CGRectMake(218, starty+j*height+37, 50, 30)];
            lbPlayerScore.textColor = [UIColor colorWithRed:21/255.f green:45/255.f blue:107/255.f alpha:255/255.f];
            lbPlayerScore.textAlignment = NSTextAlignmentCenter;
            lbPlayerScore.backgroundColor = [UIColor clearColor];
            if ([appDelegate.player.timeSpends[j] doubleValue] == -1){
                [lbPlayerScore setFont:[UIFont boldSystemFontOfSize:7]];
                lbPlayerScore.textColor = [UIColor colorWithRed:162/255.f green:19/255.f blue:19/255.f alpha:255/255.f];
                [lbPlayerScore setText:[NSString stringWithFormat:@"WRONG"]];
                [imgPlayerPanel setAlpha:0.5];
                imgPlayerBorder.hidden = YES;
            }else{
                [lbPlayerScore setFont:[UIFont boldSystemFontOfSize:7]];
                [lbPlayerScore setText:[NSString stringWithFormat:@"%.2fs",[appDelegate.player.timeSpends[j] doubleValue]]];
            }
            if ([appDelegate.timeSpends[j] doubleValue] != -1 && [appDelegate.timeSpends[j] doubleValue] < [appDelegate.player.timeSpends[j] doubleValue]){
                [imgPlayerPanel setAlpha:0.5];
                imgPlayerBorder.hidden = YES;
            }else if ([appDelegate.player.timeSpends[j] doubleValue] != -1 && [appDelegate.timeSpends[j] doubleValue] > [appDelegate.player.timeSpends[j] doubleValue]){
                [imgUserPanel setAlpha:0.5];
                imgUserBorder.hidden = YES;
            }
            [mediaScroll addSubview:lbPlayerScore];
        }else{
            
            
            [imgPlayerPanel setAlpha:0.5];
            imgPlayerBorder.hidden = YES;
        }
        
        
        
        j++;
    }
    
    // save challenge data
    NSString *media_id_array_string;
    NSString *choice_var_array_string;
    NSString *duel_elapsed_array_string;
    NSString *challenge_id = [appDelegate.challenge_type isEqualToString:@"self"] ? @"0":appDelegate.challenge_id_array[appDelegate.challengePointer];
    
    int k = 0;
    while (k < [appDelegate.media_id_array count]) {
        
        if (k == 0){
            media_id_array_string = [NSString stringWithFormat:@"%@", appDelegate.media_id_array[k]];
            choice_var_array_string = [NSString stringWithFormat:@"%@", appDelegate.choice_var_array[k]];
            duel_elapsed_array_string = [NSString stringWithFormat:@"%.2f", [appDelegate.timeSpends[k] doubleValue]];
        }else{
            media_id_array_string = [NSString stringWithFormat:@"%@,%@", media_id_array_string, appDelegate.media_id_array[k]];
            choice_var_array_string = [NSString stringWithFormat:@"%@,%@", choice_var_array_string, appDelegate.choice_var_array[k]];
            duel_elapsed_array_string = [NSString stringWithFormat:@"%@,%.2f", duel_elapsed_array_string, [appDelegate.timeSpends[k] doubleValue]];
        }
        k++;
    }
    
    
    NSString *urlString = [NSString stringWithFormat:@"%@/service/saveChallenge.php?user_id=%d&player_id=%d&user_score=%d&challenge_type=%@&challenge_id=%@&genre_type=%@&media_id_array=%@&choice_var_array=%@&duel_elapsed_array=%@&score=%g&game_id=%d&winner_id=%d&endGame=%@", appDelegate.BASE_URL, [appDelegate.user.id integerValue], [appDelegate.player.id integerValue], appDelegate.user.score, appDelegate.challenge_type, challenge_id, appDelegate.genre, media_id_array_string, choice_var_array_string, duel_elapsed_array_string, userScore, appDelegate.game_id, winner_id, endGame];
    
    NSLog(@"ffff  result%@",urlString);
    // connect to the php backend
    TBXML *xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:urlString] success:saveChallengeSuccess failure:saveChallengeFailure];
    xmlData = nil;
    
    
    bDone.enabled = YES;
    bNewGame.enabled = YES;
    
    if ([appDelegate.challenge_type isEqualToString:@"self"] || [endGame isEqualToString:@"true"]){
        bPlay.enabled = NO;
    }else{
        bPlay.enabled = YES;
    }
    
}
/*
-(void)showControl:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(showControlInMain) withObject:nil waitUntilDone:YES];
}

- (void)showControlInMain {
    bDone.enabled = YES;
    bNewGame.enabled = YES;
    
    if ([appDelegate.challenge_type isEqualToString:@"self"] || [endGame isEqualToString:@"true"]){
        bPlay.enabled = NO;
    }else{
        bPlay.enabled = YES;
    }
    
}*/

- (void) gotoURL:(UIButton *)sender {
    if (![appDelegate.etailers[sender.tag] isEqualToString:@"none"]){
        [[UIApplication sharedApplication] openURL:[[NSURL alloc] initWithString:appDelegate.etailers[sender.tag]]];
    }
}

- (IBAction)closeGrandScoreBoard:(id)sender {
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGameInfo" object:nil];
}

- (IBAction)startNewGame:(id)sender {
    
    [self.navigationController dismissViewControllerAnimated:NO completion:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"launchUserTypeSelection" object:nil];
    
}

- (IBAction)playCurrentGame:(id)sender {
    appDelegate.gameplay_round++;
    appDelegate.uid_challenge_target = appDelegate.player.id;    
    appDelegate.challenge_type = @"self";
    
    [self.navigationController dismissViewControllerAnimated:NO completion:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"launchMediaSelection" object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
