//
//  Media.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/3/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import "Media.h"

@implementation Media

@end
