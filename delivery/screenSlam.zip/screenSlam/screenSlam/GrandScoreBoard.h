//
//  GrandScoreBoard.h
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/30/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface GrandScoreBoard : UIViewController {
    AppDelegate *appDelegate;
    
    NSString *endGame;
}

@property (nonatomic, retain) AppDelegate *appDelegate;

@property (nonatomic, retain) NSString *endGame;

@property (strong, nonatomic) IBOutlet UIScrollView *mediaScroll;


@property (strong, nonatomic) IBOutlet UIButton *bDone;
@property (strong, nonatomic) IBOutlet UIButton *bNewGame;
@property (strong, nonatomic) IBOutlet UIButton *bPlay;

@property (strong, nonatomic) IBOutlet UIImageView *imgUser;
@property (strong, nonatomic) IBOutlet UIImageView *imgPlayer;
@property (strong, nonatomic) IBOutlet UILabel *txtUser;
@property (strong, nonatomic) IBOutlet UILabel *txtUserScore;
@property (strong, nonatomic) IBOutlet UILabel *txtUserGameScore;
@property (strong, nonatomic) IBOutlet UILabel *txtPlayer;
@property (strong, nonatomic) IBOutlet UILabel *txtPlayerScore;
@property (strong, nonatomic) IBOutlet UILabel *txtPlayerGameScore;
@property (strong, nonatomic) IBOutlet UILabel *txtUserWon;
@property (strong, nonatomic) IBOutlet UILabel *txtPlayerWon;
@property (strong, nonatomic) IBOutlet UILabel *txtRound;

- (IBAction)closeGrandScoreBoard:(id)sender;
- (IBAction)startNewGame:(id)sender;
- (IBAction)playCurrentGame:(id)sender;

@end
