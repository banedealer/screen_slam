//
//  MediaMainPanel.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 11/29/12.
//  Copyright (c) 2012 Oskoui+Oskoui. All rights reserved.
//

#import "MediaMainPanel.h"
#import "TotalScore.h"
#import "Facebook.h"
#include <math.h>

@interface MediaMainPanel ()

@end

@implementation MediaMainPanel
@synthesize appDelegate;
@synthesize mediaMask;
@synthesize timer;
@synthesize imgIcon;
@synthesize tempData, connect, request;
@synthesize imgCorrect,imgWrong;
@synthesize correctPointer;
@synthesize mediaPlayBackComplete;
@synthesize startTime, imagePlayer, player, soundWaveDisplay, soundPlayer, elapsedBar;
@synthesize imgQuestion,q,b0,b1,b2,b3,txtScore;
@synthesize pMedia;

static bool needToDisplayLegal=NO;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
    NSLog(@"connection error");
}

- (void)connection: (NSURLConnection *)connection didReceiveResponse:
(NSURLResponse *)aResponse
{
    NSLog(@"connection establish");
}

-(void) connection:(NSURLConnection *)connection didReceiveData:
(NSData *) incomingData
{
    [tempData appendData:incomingData];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSArray *pathList = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [pathList objectAtIndex:0];
    
    
    path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"tempIMG"]];
    NSLog(@"path：%@", path);
    
    [tempData writeToFile:path atomically:NO];
    
    tempData = nil;
    
    
    // init image player
    //NSURL *imgURL = [NSURL URLWithString:appDelegate.mediaURLs[appDelegate.videoPointer]];
    UIImage *img = [UIImage imageWithContentsOfFile:path];
    [imagePlayer setImage:img];
    startTime = [NSDate date];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // disable interacivities until media loaded
    self.view.userInteractionEnabled = NO;

    // init legal
    needToDisplayLegal = NO;
    legalImageView.alpha = 0;
    
    // fb
    /*if (appDelegate.fb_challenge_target != nil && [appDelegate.challenge_type isEqualToString:@"self"]){
        NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Screen Slam", @"title", @"Someone invite you to play screen slam.", @"message", appDelegate.fb_challenge_target, @"to", nil];
        [appDelegate.facebook dialog:@"apprequests" andParams:params andDelegate:nil];
        NSLog(@"ccccc");
    }*/
    
    // init environment
    imgCorrect.hidden = YES;
    imgWrong.hidden = YES;
    imgIcon.hidden = YES;
    
    // choice MC
    b0.alpha = 0.0;
    b1.alpha = 0.0;
    b2.alpha = 0.0;
    b3.alpha = 0.0;
    [UIView animateWithDuration:0.7 delay:0.0 options: UIViewAnimationCurveEaseInOut animations:^{b0.alpha = 1.0;} completion:nil];
    [UIView animateWithDuration:0.7 delay:0.2 options: UIViewAnimationCurveEaseInOut animations:^{b1.alpha = 1.0;} completion:nil];
    [UIView animateWithDuration:0.7 delay:0.4 options: UIViewAnimationCurveEaseInOut animations:^{b2.alpha = 1.0;} completion:nil];
    [UIView animateWithDuration:0.7 delay:0.6 options: UIViewAnimationCurveEaseInOut animations:^{b3.alpha = 1.0;} completion:nil];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"iphone_bg.jpg"]];
    appDelegate = [[UIApplication sharedApplication] delegate];
   
    appDelegate.mediaURLs[appDelegate.videoPointer] = [NSString stringWithFormat:@"%@/%@", appDelegate.BASE_URL, appDelegate.mediaURLs[appDelegate.videoPointer]];
    
    if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"image"]){
        
        // request remote image
        imgIcon.hidden = NO;
        request = [[NSMutableURLRequest alloc] init];
        if (appDelegate.isHD){
            NSLog(@"loading ipad size img");
            [request setURL:[NSURL URLWithString:[appDelegate.mediaURLs[appDelegate.videoPointer] stringByReplacingOccurrencesOfString :@"_iphone" withString:@"_ipad"]]];
            
            NSLog(@"%@",[appDelegate.mediaURLs[appDelegate.videoPointer] stringByReplacingOccurrencesOfString :@"_iphone" withString:@"_ipad"]);
        }else{
            NSLog(@"loading iphone size img");
            [request setURL:[NSURL URLWithString:appDelegate.mediaURLs[appDelegate.videoPointer]]];
            
            NSLog(@"%@",appDelegate.mediaURLs[appDelegate.videoPointer]);
        }
        
        
        
        [request setHTTPMethod:@"GET"];
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"Mobile Safari 1.1.3 (iPhone; U; CPU like Mac OS X; en)" forHTTPHeaderField:@"User-Agent"];
        tempData = [NSMutableData alloc];        
        connect = [[NSURLConnection alloc] initWithRequest:request delegate:self];
        
    }else if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"sound"]){
        
        // init sound wave display
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(repeatSoundWave:) name:MPMoviePlayerPlaybackDidFinishNotification object:soundWaveDisplay.moviePlayer];
        NSString *soundWaveDisplayPath = [[NSBundle mainBundle] pathForResource:@"soundWave" ofType:@"mp4"];
        soundWaveDisplay = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL fileURLWithPath:soundWaveDisplayPath]];
        [soundWaveDisplay.moviePlayer prepareToPlay];
        soundWaveDisplay.moviePlayer.controlStyle = MPMovieControlStyleNone;
        soundWaveDisplay.moviePlayer.shouldAutoplay = YES;
        soundWaveDisplay.moviePlayer.view.frame = CGRectMake(0, 20, 320, 180);
        soundWaveDisplay.moviePlayer.view.bounds = CGRectMake(0, 20, 320, 180);
        //[self.view addSubview:soundWaveDisplay.moviePlayer.view];
        [self.view insertSubview:soundWaveDisplay.moviePlayer.view belowSubview:elapsedBar];
        // init sound player
        NSURL *url = [NSURL URLWithString:appDelegate.mediaURLs[appDelegate.videoPointer]];
        soundPlayer = [AVPlayer playerWithURL:url];
        [soundPlayer play];
        
    }else{
    
        // init movie player
        mediaPlayBackComplete = NO;
        needToDisplayLegal = YES;
        
        NSURL *url;
        if (appDelegate.isHD){
            NSLog(@"loading ipad size video");
            url = [NSURL URLWithString:[appDelegate.mediaURLs[appDelegate.videoPointer] stringByReplacingOccurrencesOfString :@"_iphone" withString:@"_ipad"]];
        }else{
            NSLog(@"loading iphone size video");
            url = [NSURL URLWithString:appDelegate.mediaURLs[appDelegate.videoPointer]];
        }
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackEnded:) name:MPMoviePlayerPlaybackDidFinishNotification object:player.moviePlayer];
        player = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
        [player.moviePlayer prepareToPlay];
        player.moviePlayer.controlStyle = MPMovieControlStyleNone;
        player.moviePlayer.shouldAutoplay = YES;
        player.moviePlayer.view.frame = CGRectMake(0, 20, 320, 180);
        player.moviePlayer.view.bounds = CGRectMake(0, 20, 320, 180);
        //[self.view addSubview:player.moviePlayer.view];
        [self.view insertSubview:player.moviePlayer.view belowSubview:elapsedBar];
        
        //load legal image
        url = [NSURL URLWithString: [NSString stringWithFormat:
									 @"%@/legal/%@", appDelegate.BASE_URL,appDelegate.mediaLegals[appDelegate.videoPointer]]];
		NSLog(@"%@",url);
        NSData *legalData = [NSData dataWithContentsOfURL:url];
        legalImageView.image = [[UIImage alloc] initWithData:legalData];
    }
    
    
    // init elapse timer
     elapsedBar.progress = 0.0;
    timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(elapsedTimer) userInfo:nil repeats:YES];
    
    
    // init Question & options
    correctPointer = arc4random()%4;
    
    NSString *correctOption = appDelegate.choices[appDelegate.videoPointer][0];
    appDelegate.choices[appDelegate.videoPointer][0] = appDelegate.choices[appDelegate.videoPointer][correctPointer];
    appDelegate.choices[appDelegate.videoPointer][correctPointer] = correctOption;
    
    [imgQuestion setImage:[UIImage imageNamed:[NSString stringWithFormat:@"question_%@.png", appDelegate.choice_var_array[appDelegate.videoPointer]]]];
    //[q setText:appDelegate.questions[appDelegate.videoPointer]];
    [b0 setTitle:appDelegate.choices[appDelegate.videoPointer][0] forState:UIControlStateNormal];
    [b1 setTitle:appDelegate.choices[appDelegate.videoPointer][1] forState:UIControlStateNormal];
    [b2 setTitle:appDelegate.choices[appDelegate.videoPointer][2] forState:UIControlStateNormal];
    [b3 setTitle:appDelegate.choices[appDelegate.videoPointer][3] forState:UIControlStateNormal];
}

-(void) elapsedTimer{
    
    if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"image"]){
        elapsedBar.progress += 1.0/150.0;
    }else if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"sound"]){
        if (CMTimeGetSeconds([soundPlayer currentTime]) == CMTimeGetSeconds(soundPlayer.currentItem.asset.duration)){
            [soundWaveDisplay.moviePlayer pause];
        }else{
            elapsedBar.progress = CMTimeGetSeconds([soundPlayer currentTime])/CMTimeGetSeconds(soundPlayer.currentItem.asset.duration);
        }
        
    }else{
        if (mediaPlayBackComplete || player.moviePlayer.playbackState == MPMoviePlaybackStatePlaying){
            elapsedBar.progress = player.moviePlayer.currentPlaybackTime / player.moviePlayer.duration;
            if (mediaPlayBackComplete && needToDisplayLegal) {
                [UIView animateWithDuration:0.7 delay:0.0 options: UIViewAnimationCurveEaseInOut animations:^{legalImageView.alpha = 1.0;} completion:nil];
                needToDisplayLegal = NO;
            }
        }        
    }
    
    if (elapsedBar.progress != 0 && mediaMask.hidden == NO){
        // acitivate the UI components in the view
        mediaMask.hidden = YES;
        pMedia.hidden = YES;
        self.view.userInteractionEnabled = YES;
    }
}

// action when the video finsih playing
- (void)playbackEnded:(NSNotification *)notification
{
    mediaPlayBackComplete = YES;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:player.moviePlayer];
}

// action when the video finsih playing
- (void)repeatSoundWave:(NSNotification *)notification
{
    [self performSelectorOnMainThread:@selector(repeatSoundWaveInMain) withObject:nil waitUntilDone:YES];
}
- (void)repeatSoundWaveInMain
{
    [soundWaveDisplay.moviePlayer stop];
    [soundWaveDisplay.moviePlayer play];
}


// check if it is correct
- (IBAction)optionSelected:(UIButton *)sender {
    // disable all the buttons
    self.view.userInteractionEnabled = NO;
    
    // remove elapsed timer memory
    if (timer){
        [timer invalidate];
        timer = nil;
    }
    appDelegate.correctChoice = appDelegate.choices[appDelegate.videoPointer][correctPointer];
    
    // for images
    if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"image"]){
        [appDelegate.durations addObject:[[NSNumber alloc] initWithFloat:15]];
        double timeElapsed = [startTime timeIntervalSinceNow]*-1;
        if (timeElapsed > 15) timeElapsed = 15;
        if (sender.tag == correctPointer){
            [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:timeElapsed]];
        }else{
            [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:-1]];
        }
        
    // for sound
    }else if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"sound"]){
        
        [soundPlayer pause];
        double duration = 0;
        if (sender.tag == correctPointer){
            duration = CMTimeGetSeconds(soundPlayer.currentItem.asset.duration);
            [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:CMTimeGetSeconds([soundPlayer currentTime])]];
        }else{
            [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:-1]];
        }
        [appDelegate.durations addObject:[[NSNumber alloc] initWithFloat:duration]];
        
        [soundWaveDisplay.moviePlayer pause];
        soundPlayer = nil;
        
    // for videos
    }else{
        // if the video hv already finish playing or the video is loaded and playing
        double duration = 0;
        if (mediaPlayBackComplete || player.moviePlayer.playbackState == MPMoviePlaybackStatePlaying){
            if (sender.tag == correctPointer){
                duration = player.moviePlayer.duration;
                // this is a test for nan, currentPlaybackTime not valid if playback done and app is sent to background
                if ( isnan(player.moviePlayer.currentPlaybackTime) ) {
                    // currentPlaybackTime is nan
                    [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:player.moviePlayer.duration]];
                } else {
                    // currentPlaybackTime is OK
                    [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:player.moviePlayer.currentPlaybackTime]];
                }
                
            }else{
                [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:-1]];
            }
            // if the video is not even loaded and played
        }else{
            if (sender.tag == correctPointer){
                [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:0]];
            }else{
                [appDelegate.timeSpends addObject:[[NSNumber alloc] initWithFloat:-1]];
            }
        }
        [appDelegate.durations addObject:[[NSNumber alloc] initWithFloat:duration]];
        
        // remove the mmp player
        player.moviePlayer.shouldAutoplay = NO;
        [player.moviePlayer pause];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:player.moviePlayer];
    }
    
    // show correct ans
    NSMutableArray *buttonArray = [[NSMutableArray alloc] init];
    [buttonArray addObject:b0];
    [buttonArray addObject:b1];
    [buttonArray addObject:b2];
    [buttonArray addObject:b3];
    
    
    for (UIButton *button in buttonArray){
        [button setAlpha:0.7];
    }
    UIButton *bCorrect = [buttonArray objectAtIndex:correctPointer];
    [bCorrect setAlpha:1];
    
    double timeSpent = [appDelegate.timeSpends[appDelegate.videoPointer] doubleValue];
    
    // correct indicator
    if (sender.tag == correctPointer){
        //imgCorrect.hidden = NO;
        
        UIImageView *win1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"stars1.png"]];
        UIImageView *win2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"stars2.png"]];
        UIImageView *win3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"stars3.png"]];
        win1.alpha = 0;
        win2.alpha = 0;
        win3.alpha = 0;
        win1.frame = CGRectMake(35, 192+sender.tag*58, 288, 159);
        win2.frame = CGRectMake(35, 192+sender.tag*58, 288, 159);
        win3.frame = CGRectMake(35, 192+sender.tag*58, 288, 159);
        win1.contentMode = UIViewContentModeScaleToFill;
        win2.contentMode = UIViewContentModeScaleToFill;
        win3.contentMode = UIViewContentModeScaleToFill;
        [self.view addSubview:win1];
        [self.view addSubview:win2];
        [self.view addSubview:win3];
        [UIView animateWithDuration:0.4 delay:0 options: UIViewAnimationCurveEaseInOut animations:^{win1.alpha = 1.0;} completion:^(BOOL finished){ [win1 removeFromSuperview]; }];
        [UIView animateWithDuration:0.4 delay:0.1 options: UIViewAnimationCurveEaseInOut animations:^{win2.alpha = 1.0;} completion:^(BOOL finished){ [win2 removeFromSuperview]; }];
        [UIView animateWithDuration:0.4 delay:0.2 options: UIViewAnimationCurveEaseInOut animations:^{win3.alpha = 1.0;} completion:nil];
        
        
        // score
        double score = 1000;        
        if (timeSpent != 0){
            score = ceil(([appDelegate.durations[appDelegate.videoPointer] doubleValue] - timeSpent)/[appDelegate.durations[appDelegate.videoPointer] doubleValue]*900+100);
        }
        UILabel *winScore = [[UILabel alloc] init];
        winScore.alpha = 0;
        winScore.backgroundColor = [UIColor clearColor];
        winScore.textColor = [UIColor whiteColor];
        [winScore setText:[NSString stringWithFormat:@"%g",score]];
        winScore.frame = CGRectMake(91, 233+sender.tag*58, 173, 83);
        winScore.contentMode = UIViewContentModeScaleToFill;
        [winScore setFont:[UIFont boldSystemFontOfSize:30]];
        [self.view addSubview:winScore];
        [UIView animateWithDuration:0.4 delay:0.2 options: UIViewAnimationCurveEaseInOut animations:^{winScore.alpha = 1.0;} completion:nil];
        
        // play correct sound effect
        NSURL *soundURL = [[NSBundle mainBundle] URLForResource:@"correct" withExtension:@"mp3"];
        soundPlayer = [AVPlayer playerWithURL:soundURL];
        [soundPlayer play];
        
        [self performSelector:@selector(gotoNextMedia) withObject:nil afterDelay:2];
        
    // wrong indicator
    }else{
        
        imgWrong.hidden = NO;
        imgWrong.frame = CGRectMake(120, 230+sender.tag*58, 84, 78);
        imgWrong.contentMode = UIViewContentModeScaleToFill;
        
        // play incorrect sound effect
        NSURL *soundURL = [[NSBundle mainBundle] URLForResource:@"incorrect" withExtension:@"mp3"];
        soundPlayer = [AVPlayer playerWithURL:soundURL];
        [soundPlayer play];
        
        [self performSelector:@selector(gotoNextMedia) withObject:nil afterDelay:3];
    }
    
}

-(void)gotoNextMedia {
    
    
    // release memory
    
    // stop all sound effect win/lost
    [soundPlayer pause];
    
    // for images
    if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"image"]){
        [imagePlayer removeFromSuperview];
    // for sound
    }else if ([appDelegate.mediaType[appDelegate.videoPointer] isEqualToString:@"sound"]){
        [soundWaveDisplay.moviePlayer.view removeFromSuperview];
        
    // for videos
    }else{        
        // remove the mmp player
        [player.moviePlayer stop];
        player.moviePlayer.initialPlaybackTime = -1;
        [player.moviePlayer.view removeFromSuperview];
    }
    /*
    // go to score board
    ScoreBoard *scoreBoard = [[ScoreBoard alloc] initWithNibName:@"ScoreBoard" bundle:nil];
    [self.navigationController pushViewController:scoreBoard animated:YES];
     */
    
    
    if (appDelegate.videoPointer < [appDelegate.mediaURLs count] - 1){
        appDelegate.videoPointer++;
        MediaMainPanel *mediaMainPanel = [[MediaMainPanel alloc] initWithNibName:@"MediaMainPanel" bundle:nil];
        [self.navigationController pushViewController:mediaMainPanel animated:YES];
    }else{
        TotalScore *totalScore = [[TotalScore alloc] initWithNibName:@"TotalScore" bundle:nil];
        [self.navigationController pushViewController:totalScore animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
