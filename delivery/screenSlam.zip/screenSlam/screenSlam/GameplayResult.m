//
//  GameplayResult.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/6/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import "GameplayResult.h"
#import "TBXML+HTTP.h"

@interface GameplayResult ()

@end

@implementation GameplayResult
@synthesize appDelegate;
@synthesize pbHistory;


// static function that handle xml parsing
TBXMLFailureBlock getGameplayHistoryfailureBlock = ^(TBXML *tbxmlDocument, NSError * error) {
    NSLog(@"Error! %@ %@", [error localizedDescription], [error userInfo]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionError" object:nil];
};

TBXMLSuccessBlock getGameplayHistorysuccessBlock = ^(TBXML *tbxmlDocument) {
        
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];    
    appDelegate.history_array = [[NSMutableArray alloc] init];
    
    TBXMLElement *rootElement = tbxmlDocument.rootXMLElement;
    TBXMLElement *gameplays = [TBXML childElementNamed:@"gameplays" parentElement:rootElement];    
    TBXMLElement *gameplayElement = [TBXML childElementNamed:@"gameplay" parentElement:gameplays];
    
    
    while (gameplayElement != nil){
        User *user = [[User alloc] init];
        
        
        TBXMLElement *user_won = [TBXML childElementNamed:@"user_won" parentElement:gameplayElement];
        user.won = [[TBXML textForElement:user_won] integerValue];
        
        TBXMLElement *player_won = [TBXML childElementNamed:@"player_won" parentElement:gameplayElement];
        user.opponent_won = [[TBXML textForElement:player_won] integerValue];
        
        [appDelegate.history_array addObject:user];
        
        gameplayElement = [TBXML nextSiblingNamed:@"gameplay" searchFromElement:gameplayElement];
        NSLog(@"finish xml load %d : %d", user.won, user.opponent_won);
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"historyLoaded" object:nil];
    
};

-(void)displayHistory:(NSNotification *)notice{
    [self performSelectorOnMainThread:@selector(displayHistoryInMain) withObject:nil waitUntilDone:YES];
    
}

-(void)displayHistoryInMain {
    pbHistory.hidden = YES;
    int i=0;
    int starty = 130;
    int height = 55;
    while (i < [appDelegate.history_array count]) {
        
        User *user = appDelegate.history_array[i];
        
        // display score
        UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(70, starty+i*height+10, 180, 30)];
        l.textColor = [UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:255/255.f];
        l.backgroundColor = [UIColor clearColor];
        l.textAlignment = NSTextAlignmentCenter;
        if (user.won == -1 || user.opponent_won == -1){
            [l setText:[NSString stringWithFormat:@"- : -"]];
        }else{
            [l setText:[NSString stringWithFormat:@"%d : %d",user.won, user.opponent_won]];
        }        
        [l setFont:[UIFont boldSystemFontOfSize:20]];
        [self.view addSubview:l];
        
        // display player avator
        User *player = appDelegate.challenge_player[appDelegate.challengePointer];
        NSData *playerPanelData = [NSData dataWithContentsOfURL:[NSURL URLWithString:player.thumbnail]];        
        UIImageView *imgPlayerPanel = [[UIImageView alloc] initWithImage:[UIImage imageWithData:playerPanelData]];
        imgPlayerPanel.frame = CGRectMake(190, starty+i*height+5, 40, 40);
        imgPlayerPanel.contentMode = UIViewContentModeScaleAspectFill;
        imgPlayerPanel.clipsToBounds = YES;
        [self.view addSubview:imgPlayerPanel];
        
        // display user avator
        UIImageView *imgUserPanel = [[UIImageView alloc] initWithImage:appDelegate.imgUserData];
        imgUserPanel.frame = CGRectMake(90, starty+i*height+5, 40, 40);
        imgUserPanel.contentMode = UIViewContentModeScaleAspectFill;
        imgUserPanel.clipsToBounds = YES;
        [self.view addSubview:imgUserPanel];
        
        // check winner
        if (user.won > user.opponent_won){
            // display user border
            UIImageView *imgUserBorder = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"profileBorder.png"]];
            imgUserBorder.frame = CGRectMake(90-1, starty+i*height+4, 42, 42);
            imgUserBorder.contentMode = UIViewContentModeScaleAspectFill;
            imgUserBorder.clipsToBounds = YES;
            [self.view addSubview:imgUserBorder];
            
            imgPlayerPanel.alpha = 0.5;
        }else if (user.won < user.opponent_won){
            // display player border
            UIImageView *imgPlayerBorder = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"profileBorder.png"]];
            imgPlayerBorder.frame = CGRectMake(190-1, starty+i*height+4, 42, 42);
            imgPlayerBorder.contentMode = UIViewContentModeScaleAspectFill;
            imgPlayerBorder.clipsToBounds = YES;
            [self.view addSubview:imgPlayerBorder];
            
            imgUserPanel.alpha = 0.5;
        }
        
        i++;
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    // add listeners
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayHistory:) name:@"historyLoaded" object:nil];
    
    // display past result
    TBXML *xmlData;
    xmlData = [[TBXML alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/service/getPastGameplay.php?user_id=%d&player_id=%d", appDelegate.BASE_URL, [appDelegate.user.id integerValue], [appDelegate.player.id integerValue]]] success:getGameplayHistorysuccessBlock failure:getGameplayHistoryfailureBlock];
    xmlData = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)closeResult:(id)sender {    
    [UIView beginAnimations:@"LeftFlip" context:nil];
    [UIView setAnimationDuration:0.8];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.navigationController.view.superview cache:YES];
    [UIView commitAnimations];
    [self.navigationController dismissViewControllerAnimated:NO completion:nil];
}

@end
