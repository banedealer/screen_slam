//
//  TermsScreen.m
//  screenSlam
//
//  Created by Oskoui+Oskoui on 1/16/13.
//  Copyright (c) 2013 Oskoui+Oskoui. All rights reserved.
//

#import "TermsScreen.h"

@interface TermsScreen ()

@end

@implementation TermsScreen
@synthesize termsScroll;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    [termsScroll flashScrollIndicators];
    [termsScroll setScrollEnabled:YES];
    [termsScroll setContentSize:CGSizeMake(260, 7590+88)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)closeTermsScreen:(id)sender {
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
@end
